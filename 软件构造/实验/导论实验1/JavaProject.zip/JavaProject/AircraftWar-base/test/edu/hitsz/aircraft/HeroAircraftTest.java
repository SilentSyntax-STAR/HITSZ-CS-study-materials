package edu.hitsz.aircraft;

import edu.hitsz.bullet.BaseBullet;
import org.junit.jupiter.api.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class HeroAircraftTest {

    private HeroAircraft heroAircraft;

    @BeforeEach
    void setUp() {
        HeroAircraft.resetInstance();
        heroAircraft = HeroAircraft.getInstance(200, 600, 0, 0, 100);
    }

    @AfterEach
    void tearDown() {
        HeroAircraft.resetInstance();
        heroAircraft = null;
    }

    @Test
    void testGetInstanceSingleton() {
        HeroAircraft another = HeroAircraft.getInstance(300, 500, 1, 1, 80);
        assertSame(heroAircraft, another);
    }

    @Test
    void testSetHp() {
        heroAircraft.setHp(200);
        assertEquals(100, heroAircraft.getHp());
    }

    @Test
    void testDecreaseHp() {
        heroAircraft.decreaseHp(30);
        assertEquals(70, heroAircraft.getHp());
    }

    @Test
    void testFrozenState() {
        heroAircraft.setFrozen(true);
        assertTrue(heroAircraft.isFrozen());

        heroAircraft.setFrozen(false);
        assertFalse(heroAircraft.isFrozen());
    }

    @Test
    void testShoot() {
        List<BaseBullet> bullets = heroAircraft.shoot();
        assertNotNull(bullets);
        assertFalse(bullets.isEmpty());
    }
}