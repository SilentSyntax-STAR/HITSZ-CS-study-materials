package edu.hitsz.application;

import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JPanel;

public abstract class GameTemplate extends JPanel {

    protected Timer timer;
    protected int timeInterval = 40;

    public GameTemplate(){
        timer = new Timer();
    }

    // 模板方法（核心）
    public final void action(){

        TimerTask task = new TimerTask() {

            @Override
            public void run() {

                enemyGenerateAction();

                spawnBoss();

                shootAction();

                moveAction();

                crashCheckAction();

                postProcessAction();

                difficultyUpgrade();

                repaint();

                checkResultAction();
            }
        };

        timer.schedule(task,0,timeInterval);
    }


    protected abstract void enemyGenerateAction();

    protected abstract void spawnBoss();

    protected abstract void shootAction();

    protected abstract void moveAction();

    protected abstract void crashCheckAction();

    protected abstract void postProcessAction();

    protected abstract void difficultyUpgrade();

    protected abstract void checkResultAction();

}