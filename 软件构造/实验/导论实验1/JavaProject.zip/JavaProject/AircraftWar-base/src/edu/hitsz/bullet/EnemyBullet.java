package edu.hitsz.bullet;

import edu.hitsz.observer.Observer;

/**
 * 敌机子弹
 * @author hitsz
 */
public class EnemyBullet extends BaseBullet implements Observer {

    public EnemyBullet(int locationX, int locationY, int speedX, int speedY, int power) {
        super(locationX, locationY, speedX, speedY, power);
    }

    @Override
    public void update(String event) {

        if ("BOMB".equals(event)) {
            // 炸弹：清除敌机子弹
            this.vanish();
        } else if ("FROZEN".equals(event)) {
            // 冰冻：敌机子弹也清除
            this.vanish();
        }
    }
}