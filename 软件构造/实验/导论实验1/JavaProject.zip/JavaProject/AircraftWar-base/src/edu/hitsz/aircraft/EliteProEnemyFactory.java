package edu.hitsz.aircraft;

/**
 * 王牌敌机工厂
 */
public class EliteProEnemyFactory implements EnemyFactory {
    @Override
    public AbstractAircraft createEnemy(int locationX, int locationY) {
        return new EliteProEnemy(locationX, locationY, 2, 7, 80);
    }
}