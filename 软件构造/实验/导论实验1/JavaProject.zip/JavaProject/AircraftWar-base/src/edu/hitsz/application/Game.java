package edu.hitsz.application;

import edu.hitsz.aircraft.*;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.basic.AbstractFlyingObject;
import edu.hitsz.prop.AbstractProp;
import edu.hitsz.prop.PropFactory;
import edu.hitsz.dao.ScoreRecord;
import edu.hitsz.dao.ScoreRecordDao;
import edu.hitsz.dao.ScoreRecordDaoImpl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.TimerTask;
import edu.hitsz.application.SoundPlayer;
/**
 * 游戏主面板，实验二改造版：简单工厂+工厂方法
 */
public class Game extends GameTemplate {
    private int backGroundTop = 0;
    private final HeroAircraft heroAircraft;
    private final List<AbstractAircraft> enemyAircraft;
    private final List<BaseBullet> heroBullets;
    private final List<BaseBullet> enemyBullets;
    private final List<AbstractProp> props;
    private int enemyMaxNumber = 6;
    protected double enemySpawnCycle = 20;
    private int enemySpawnCounter = 0;
    protected double heroShootCycle = 8;
    protected double enemyShootCycle = 18;
    private int heroShootCounter = 0;
    private int enemyShootCounter = 0;
    private int score = 0;
    private boolean gameOverFlag = false;
    private final Random random = new Random();
    private boolean isBossSpawned = false;
    private int difficultyLevel = 1;
    private int nextBossScore = BossEnemy.SCORE_THRESHOLD;

    private int bossShootCounter = 0;
    private int bossShootCycle = 45;
    private volatile long enemyFrozenUntil = 0;

    private Difficulty difficulty;

    public Game(Difficulty difficulty) {
        HeroAircraft.resetInstance();
        this.difficulty = difficulty;

        if (difficulty == Difficulty.EASY) {
            bossShootCycle = 9999;   // 简单模式没Boss
        } else if (difficulty == Difficulty.NORMAL) {
            bossShootCycle = 50;     // 普通模式约2秒射一次
        } else {
            bossShootCycle = 35;     // 困难模式约1.4秒射一次
        }

        heroAircraft = HeroAircraft.getInstance(
                Main.WINDOW_WIDTH / 2,
                Main.WINDOW_HEIGHT - ImageManager.HERO_IMAGE.getHeight(),
                0, 0, 100);

        enemyAircraft = new LinkedList<>();
        heroBullets = new LinkedList<>();
        enemyBullets = new LinkedList<>();
        props = new LinkedList<>();

        new HeroController(this, heroAircraft);
        if (difficulty == Difficulty.EASY) {
            enemyMaxNumber = 5;
            enemySpawnCycle = 25;
        } else if (difficulty == Difficulty.NORMAL) {
            enemyMaxNumber = 6;
            enemySpawnCycle = 20;
        } else {
            enemyMaxNumber = 8;
            enemySpawnCycle = 15;
        }

        if (difficulty == Difficulty.EASY) {
            backgroundImage = ImageManager.BACKGROUND_EASY_IMAGE;
        } else if (difficulty == Difficulty.NORMAL) {
            backgroundImage = ImageManager.BACKGROUND_NORMAL_IMAGE;
        } else {
            backgroundImage = ImageManager.BACKGROUND_HARD_IMAGE;
        }
        // 背景音乐线程启动
        bgmThread = new MusicThread("src/videos/bgm.wav");
        bgmThread.start();
    }

    @Override
    protected void moveAction(){
        bulletsMoveAction();
        aircraftMoveAction();
        propsMoveAction();
    }


    /**
     * 实验二改造：工厂方法模式创建敌机
     */
    protected void spawnEnemy() {
        int roll = random.nextInt(100);
        EnemyFactory factory;

        if (roll < 45) {
            factory = new MobEnemyFactory();          // 45%
        } else if (roll < 75) {
            factory = new EliteEnemyFactory();        // 30%
        } else if (roll < 92) {
            factory = new ElitePlusEnemyFactory();    // 17%
        } else {
            factory = new EliteProEnemyFactory();     // 8%
        }

        int x = random.nextInt(Main.WINDOW_WIDTH - 50);
        int y = random.nextInt((int) (Main.WINDOW_HEIGHT * 0.05));
        AbstractAircraft enemy = factory.createEnemy(x, y);
        if (isEnemyFreezeActive()) {
            enemy.setFrozen(true);
        }
        enemyAircraft.add(enemy);
    }

    // Boss生成逻辑
    protected void spawnBoss() {
        if (score >= nextBossScore && !isBossSpawned) {
            boolean bossExist = false;
            for (AbstractAircraft e : enemyAircraft) {
                if (e instanceof BossEnemy) {
                    bossExist = true;
                    break;
                }
            }
            if (!bossExist) {
                BossEnemy boss = createBoss();
                enemyAircraft.add(boss);
                isBossSpawned = true;
                bgmThread.stopMusic();
                bgmThread = new MusicThread("src/videos/bgm_boss.wav");
                bgmThread.start();
                // Boss 出场时清空当前敌机子弹，给玩家反应时间
                enemyBullets.clear();
                bossShootCounter = 0;
                System.out.println("Boss敌机生成！当前分数：" + score);
            }
        }
    }

    /**
     * 创建Boss敌机
     * 普通模式默认500血
     */
    protected BossEnemy createBoss() {
        return new BossEnemy(Main.WINDOW_WIDTH / 2, 100, 5, 0);
    }

    protected void shootAction() {
        heroShootCounter++;
        enemyShootCounter++;
        bossShootCounter++;

        // 英雄机射击
        if (heroShootCounter >= heroShootCycle) {
            heroShootCounter = 0;
            heroBullets.addAll(heroAircraft.shoot());
        }

        // 普通敌机、精英敌机射击
        if (enemyShootCounter >= enemyShootCycle) {
            enemyShootCounter = 0;

            for (AbstractAircraft enemy : enemyAircraft) {
                if (!enemy.notValid()
                        && !enemy.isFrozen()
                        && !(enemy instanceof BossEnemy)) {

                    enemyBullets.addAll(enemy.shoot());
                }
            }
        }

        // Boss 单独射击，频率更低
        if (bossShootCounter >= bossShootCycle) {
            bossShootCounter = 0;

            for (AbstractAircraft enemy : enemyAircraft) {
                if (!enemy.notValid()
                        && !enemy.isFrozen()
                        && enemy instanceof BossEnemy) {

                    enemyBullets.addAll(enemy.shoot());
                }
            }
        }
    }

    private void bulletsMoveAction() {
        for (BaseBullet bullet : heroBullets) {
            bullet.forward();
        }
        for (BaseBullet bullet : enemyBullets) {
            bullet.forward();
        }
    }

    private void aircraftMoveAction() {
        for (AbstractAircraft enemy : enemyAircraft) {
            enemy.forward();
        }
    }

    public void freezeEnemies(long durationMillis) {
        long frozenUntil = System.currentTimeMillis() + durationMillis;
        enemyFrozenUntil = Math.max(enemyFrozenUntil, frozenUntil);

        for (AbstractAircraft enemy : enemyAircraft) {
            if (!enemy.notValid()) {
                enemy.setFrozen(true);
            }
        }

        enemyBullets.clear();

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (System.currentTimeMillis() < enemyFrozenUntil) {
                    return;
                }

                for (AbstractAircraft enemy : enemyAircraft) {
                    if (!enemy.notValid()) {
                        enemy.setFrozen(false);
                    }
                }
                System.out.println("敌机解冻！");
            }
        }, durationMillis);
    }

    private boolean isEnemyFreezeActive() {
        return System.currentTimeMillis() < enemyFrozenUntil;
    }

    private void propsMoveAction() {
        for (AbstractProp prop : props) {
            prop.forward();
        }
    }

    @Override
    protected void enemyGenerateAction() {
        enemySpawnCounter++;

        if (enemySpawnCounter >= enemySpawnCycle) {
            enemySpawnCounter = 0;

            if (enemyAircraft.size() < enemyMaxNumber) {
                spawnEnemy();
            }
        }
    }

    protected void crashCheckAction() {
        // 敌机子弹打英雄
        for (BaseBullet bullet : enemyBullets) {
            if (bullet.notValid()) continue;
            if (heroAircraft.crash(bullet)) {
                heroAircraft.decreaseHp(bullet.getPower());
                bullet.vanish();
            }
        }

        // 英雄子弹打敌机
        for (BaseBullet bullet : heroBullets) {
            if (bullet.notValid()) continue;
            for (AbstractAircraft enemy : enemyAircraft) {
                if (enemy.notValid()) continue;
                if (enemy.crash(bullet)) {
                    enemy.decreaseHp(bullet.getPower());
                    bullet.vanish();
                    SoundPlayer.playOnce("src/videos/bullet_hit.wav");
                    if (enemy.notValid()) {
                        // 计分
                        if (enemy instanceof MobEnemy) {
                            score += 10;
                        } else if (enemy instanceof EliteEnemy) {
                            score += 20;
                        } else if (enemy instanceof ElitePlusEnemy) {
                            score += 30;
                        } else if (enemy instanceof EliteProEnemy) {
                            score += 50;
                        } else if (enemy instanceof BossEnemy) {
                            score += 500;
                            isBossSpawned = false;
                            nextBossScore = score + BossEnemy.SCORE_THRESHOLD;
                            bgmThread.stopMusic();
                            bgmThread = new MusicThread("src/videos/bgm.wav");
                            bgmThread.start();
                        }

                        // 掉落道具：普通敌机不掉，其余敌机必掉
                        if (enemy instanceof BossEnemy) {
                            for (int i = 0; i < 3; i++) {
                                createProp(enemy);
                            }
                        } else if (enemy instanceof ElitePlusEnemy || enemy instanceof EliteProEnemy) {
                            createProp(enemy);
                        }
                    }
                        // MobEnemy 和 EliteEnemy 都不掉落
                }
            }
        }

        // 英雄撞敌机
        for (AbstractAircraft enemy : enemyAircraft) {
            if (enemy.notValid()) continue;
            if (enemy.crash(heroAircraft)) {
                enemy.vanish();
                heroAircraft.decreaseHp(Integer.MAX_VALUE);
            }
        }

        // 英雄吃道具
        for (AbstractProp prop : props) {
            if (prop.notValid()) continue;
            if (prop.crash(heroAircraft)) {
                prop.effect(heroAircraft);
                prop.vanish();
            }
        }


    }

    /**
     * 实验二改造：简单工厂模式创建道具 + 修正掉落规则
     */
    private void createProp(AbstractAircraft enemy) {
        int x = enemy.getLocationX();
        int y = enemy.getLocationY();
        int speedX = 0;
        int speedY = 5;
        String propType;

        if (enemy instanceof ElitePlusEnemy) {
            // 精锐敌机：4种，不含冰冻
            int type = random.nextInt(4);
            switch (type) {
                case 0:
                    propType = "BLOOD";
                    break;
                case 1:
                    propType = "FIRE";
                    break;
                case 2:
                    propType = "FIRE_PLUS";
                    break;
                default:
                    propType = "BOMB";
                    break;
            }
        } else {
            // 王牌敌机 / Boss：5种全掉
            int type = random.nextInt(5);
            switch (type) {
                case 0:
                    propType = "BLOOD";
                    break;
                case 1:
                    propType = "FIRE";
                    break;
                case 2:
                    propType = "FIRE_PLUS";
                    break;
                case 3:
                    propType = "BOMB";
                    break;
                default:
                    propType = "FROZEN";
                    break;
            }
        }

        AbstractProp prop = PropFactory.createProp(propType, x, y, speedX, speedY, this);
        props.add(prop);
    }

    protected void difficultyUpgrade() {
        int newLevel = score / 1000 + 1;
        if (newLevel > difficultyLevel) {
            difficultyLevel = newLevel;

            // 敌机逐渐变多
            enemyMaxNumber = Math.min(8, 5 + (difficultyLevel - 1));

            // 敌机生成更快
            enemySpawnCycle = Math.max(16, 30 - (difficultyLevel - 1) * 3);

            // 英雄射击略微加快，保持爽感
            heroShootCycle = Math.max(5, 8 - (difficultyLevel - 1));

            // 敌机射击也变快，但不要太夸张
            enemyShootCycle = Math.max(10, 18 - (difficultyLevel - 1) * 2);

            System.out.println("难度提升！当前等级：" + difficultyLevel);
            System.out.println("enemyMaxNumber=" + enemyMaxNumber
                    + ", enemySpawnCycle=" + enemySpawnCycle
                    + ", heroShootCycle=" + heroShootCycle
                    + ", enemyShootCycle=" + enemyShootCycle);
        }
    }

    protected void postProcessAction() {
        heroBullets.removeIf(AbstractFlyingObject::notValid);
        enemyBullets.removeIf(AbstractFlyingObject::notValid);
        enemyAircraft.removeIf(AbstractFlyingObject::notValid);
        props.removeIf(AbstractFlyingObject::notValid);
    }

    protected void checkResultAction() {
        if (heroAircraft.getHp() <= 0 && !gameOverFlag) {
            timer.cancel();
            gameOverFlag = true;
            if(bgmThread!=null){
                bgmThread.stopMusic();
            }
            SoundPlayer.playOnce("src/videos/game_over.wav");

            System.out.println("Game Over! 最终得分：" + this.score);

            int option = JOptionPane.showConfirmDialog(
                    this,
                    "Game Over!\n最终得分：" + score + "\n是否保存本局记录？",
                    "游戏结束",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE
            );

            if (option == JOptionPane.YES_OPTION) {
                saveScoreRecord();
            }

            showRankMenu();

            Window gameWindow = SwingUtilities.getWindowAncestor(this);
            if (gameWindow != null) {
                gameWindow.dispose();
            }
        }
    }

    private void showRankMenu() {
        JFrame frame = new JFrame("排行榜");
        frame.setContentPane(new RankMenu(getRecordFileName()).getMainPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 500);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        // 绘制背景滚动
        g.drawImage(backgroundImage, 0, this.backGroundTop - Main.WINDOW_HEIGHT, null);
        g.drawImage(backgroundImage, 0, this.backGroundTop, null);
        this.backGroundTop += 1;
        if (this.backGroundTop == Main.WINDOW_HEIGHT) {
            this.backGroundTop = 0;
        }
        // 绘制子弹、敌机、道具
        paintImageWithPositionRevised(g, enemyBullets);
        paintImageWithPositionRevised(g, heroBullets);
        paintImageWithPositionRevised(g, enemyAircraft);
        paintImageWithPositionRevised(g, props);
        // 绘制英雄机
        g.drawImage(ImageManager.HERO_IMAGE, heroAircraft.getLocationX() - ImageManager.HERO_IMAGE.getWidth() / 2,
                heroAircraft.getLocationY() - ImageManager.HERO_IMAGE.getHeight() / 2, null);
        // 绘制分数、生命值、难度
        paintScoreAndLife(g);
        // 绘制Boss血条
        paintBossHp(g);
    }

    private void paintBossHp(Graphics g) {
        for (AbstractAircraft enemy : enemyAircraft) {
            if (enemy instanceof BossEnemy && !enemy.notValid()) {
                BossEnemy boss = (BossEnemy) enemy;
                int x = boss.getLocationX() - boss.getWidth() / 2;
                int y = boss.getLocationY() - 10;
                int width = boss.getWidth();
                int height = 5;
                g.setColor(Color.GRAY);
                g.fillRect(x, y, width, height);
                g.setColor(Color.RED);
                int hpWidth = (int) ((double) boss.getHp() / boss.getMaxHp() * width);
                g.fillRect(x, y, hpWidth, height);
                g.setColor(Color.WHITE);
                g.drawString("Boss HP", x + width / 2 - 20, y - 5);
            }
        }
    }

    private void paintImageWithPositionRevised(Graphics g, List<? extends AbstractFlyingObject> objects) {
        if (objects.isEmpty()) {
            return;
        }
        for (AbstractFlyingObject object : objects) {
            BufferedImage image = object.getImage();
            assert image != null : objects.getClass().getName() + " has no image! ";
            g.drawImage(image, object.getLocationX() - image.getWidth() / 2,
                    object.getLocationY() - image.getHeight() / 2, null);
        }
    }

    private void paintScoreAndLife(Graphics g) {
        int x = 10;
        int y = 25;
        g.setColor(Color.RED);
        g.setFont(new Font("SansSerif", Font.BOLD, 22));
        g.drawString("得分: " + this.score, x, y);
        y += 20;
        g.drawString("生命: " + this.heroAircraft.getHp(), x, y);
        y += 20;
        g.drawString("等级: " + this.difficultyLevel, x, y);
        y += 20;
        String modeText;

        if (difficulty == Difficulty.EASY) {
            modeText = "简单";
        }
        else if (difficulty == Difficulty.NORMAL) {
            modeText = "普通";
        }
        else {
            modeText = "困难";
        }

        y += 20;
        g.drawString("模式: " + modeText, x, y);
    }

    /**
     * 根据当前难度返回排行榜文件名
     */
    private String getRecordFileName() {

        if (difficulty == Difficulty.EASY) {
            return "data/record_easy.txt";
        }

        if (difficulty == Difficulty.NORMAL) {
            return "data/record_normal.txt";
        }

        return "data/record_hard.txt";
    }

    /**
     * 保存当前游戏记录
     */
    private void saveScoreRecord() {
        String playerName = JOptionPane.showInputDialog(
                this,
                "请输入玩家名称：",
                "保存成绩",
                JOptionPane.PLAIN_MESSAGE
        );

        if (playerName == null || playerName.trim().isEmpty()) {
            playerName = "Anonymous";
        }

        String fileName = getRecordFileName();
        ScoreRecordDao dao = new ScoreRecordDaoImpl(fileName);

        String time = LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        );

        // 这里用4参数版本：rank, playerName, score, time
        ScoreRecord currentRecord = new ScoreRecord(0, playerName, score, time);

        dao.doAdd(currentRecord);
        dao.sortRecords();
        dao.save();

        System.out.println("成绩已保存到：" + fileName);
    }

    /**
     * 打印当前难度排行榜
     */
    private void printRankList() {
        String fileName = getRecordFileName();
        ScoreRecordDao dao = new ScoreRecordDaoImpl(fileName);
        dao.sortRecords();

        System.out.println("========================================");
        System.out.println("当前难度 LEVEL " + difficultyLevel + " 总分排行榜");
        System.out.println("名次\t玩家名\t得分\t时间");

        for (ScoreRecord record : dao.getAllRecords()) {
            System.out.println(record.getRank() + "\t"
                    + record.getPlayerName() + "\t"
                    + record.getScore() + "\t"
                    + record.getTime());
        }

        System.out.println("========================================");
    }

    public List<AbstractAircraft> getEnemyAircraft() {
        return enemyAircraft;
    }

    public List<BaseBullet> getEnemyBullets() {
        return enemyBullets;
    }

    private BufferedImage backgroundImage;

    private MusicThread bgmThread;

    public void addScoreByBomb() {
        for (AbstractAircraft enemy : enemyAircraft) {
            if (!enemy.notValid()) {
                if (enemy instanceof MobEnemy) {
                    score += 10;
                } else if (enemy instanceof EliteEnemy) {
                    score += 20;
                } else if (enemy instanceof ElitePlusEnemy) {
                    score += 30;
                } else if (enemy instanceof EliteProEnemy) {
                    score += 50;
                } else if (enemy instanceof BossEnemy) {
                    // Boss 不被炸弹秒杀，所以这里不给500分
                    // 等玩家真正打死Boss时再加500分
                }
            }
        }
    }


}
