package edu.hitsz.application;

import edu.hitsz.aircraft.BossEnemy;

public class HardGame extends Game {

    /**
     * 困难模式Boss初始血量
     */
    private int bossHp = 500;

    public HardGame() {
        super(Difficulty.HARD);
    }

    @Override
    protected void difficultyUpgrade() {
        super.difficultyUpgrade();

        // 困难模式保留父类难度递增逻辑
    }

    /**
     * 困难模式：每次生成Boss后，下次Boss血量增加
     */
    @Override
    protected BossEnemy createBoss() {
        BossEnemy boss = new BossEnemy(
                Main.WINDOW_WIDTH / 2,
                100,
                5,
                0,
                bossHp
        );

        System.out.println("困难模式Boss生成！本次Boss血量：" + bossHp);

        // 下一次Boss血量提高
        bossHp += 100;

        return boss;
    }
}