package edu.hitsz.prop;

import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.application.Game;
import edu.hitsz.observer.Observer;
import edu.hitsz.observer.Subject;

import java.util.LinkedList;
import java.util.List;

/**
 * 冰冻道具
 * 被观察者 Subject
 * 生效：通知敌机冻结，敌机子弹消失，5秒后通知敌机解冻
 */
public class FrozenProp extends AbstractProp implements Subject {

    private Game game;

    private static final int FROZEN_DURATION = 5000;

    private List<Observer> observers = new LinkedList<>();

    public FrozenProp(int locationX, int locationY, int speedX, int speedY, Game game) {
        super(locationX, locationY, speedX, speedY);
        this.game = game;
    }

    @Override
    public void effect(HeroAircraft heroAircraft) {

        playSupplySound();

        System.out.println("FrozenProp active! 观察者模式：通知敌机冻结5秒");

        game.freezeEnemies(FROZEN_DURATION);
        this.vanish();
    }

    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String event) {
        for (Observer observer : observers) {
            observer.update(event);
        }
    }
}
