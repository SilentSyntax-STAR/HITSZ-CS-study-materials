package edu.hitsz.strategy;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;
import edu.hitsz.bullet.HeroBullet;
import java.util.LinkedList;
import java.util.List;

/**
 * 散射策略（王牌敌机、英雄机火力道具专用）
 */
public class ScatterShootStrategy implements ShootStrategy {
    @Override
    public List<BaseBullet> shoot(AbstractAircraft aircraft) {
        List<BaseBullet> res = new LinkedList<>();
        int x = aircraft.getLocationX();
        int y = aircraft.getLocationY() + aircraft.getDirection() * 20;
        int power = aircraft.getPower();
        int direction = aircraft.getDirection();

        // 三发散射
        int baseSpeedY = 8;  // 子弹速度大小
        int verticalSpeed = (aircraft.getDirection() == -1) ? -baseSpeedY : baseSpeedY;

        if (direction == -1) {
            res.add(new HeroBullet(x - 20, y, -3, verticalSpeed, power));
            res.add(new HeroBullet(x, y, 0, verticalSpeed, power));
            res.add(new HeroBullet(x + 20, y, 3, verticalSpeed, power));
        } else {
            res.add(new EnemyBullet(x - 20, y, -3, verticalSpeed, power));
            res.add(new EnemyBullet(x, y, 0, verticalSpeed, power));
            res.add(new EnemyBullet(x + 20, y, 3, verticalSpeed, power));
        }
        return res;
    }
}