package edu.hitsz.strategy;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;
import java.util.LinkedList;
import java.util.List;

/**
 * 双排直射策略（精锐敌机专用）
 */
public class DoubleDirectShootStrategy implements ShootStrategy {
    @Override
    public List<BaseBullet> shoot(AbstractAircraft aircraft) {
        List<BaseBullet> res = new LinkedList<>();
        int x = aircraft.getLocationX();
        int y = aircraft.getLocationY() + aircraft.getDirection() * 20;
        int speedY = aircraft.getSpeedY();
        int power = aircraft.getPower();

        res.add(new EnemyBullet(x - 15, y, -2, speedY, power));
        res.add(new EnemyBullet(x + 15, y, 2, speedY, power));
        return res;
    }
}