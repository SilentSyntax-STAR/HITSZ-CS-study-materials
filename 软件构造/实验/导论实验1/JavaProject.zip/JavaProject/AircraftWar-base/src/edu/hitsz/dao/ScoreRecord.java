package edu.hitsz.dao;

/**
 * 排行榜记录实体类（VO）
 */
public class ScoreRecord {
    private int rank;
    private String playerName;
    private int score;
    private String time;

    public ScoreRecord(int rank, String playerName, int score, String time) {
        this.rank = rank;
        this.playerName = playerName;
        this.score = score;
        this.time = time;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    /**
     * 文件存储格式：名次,玩家名,得分,时间
     */
    @Override
    public String toString() {
        return rank + "," + playerName + "," + score + "," + time;
    }
}