package edu.hitsz.aircraft;

import edu.hitsz.application.Main;
import edu.hitsz.strategy.CircleShootStrategy;

public class BossEnemy extends AbstractAircraft {
    public static final int SCORE_THRESHOLD = 200;
    private static final int BOSS_HP = 500;

    /**
     * 普通构造方法：默认Boss血量500
     * 普通模式用这个
     */
    public BossEnemy(int locationX, int locationY, int speedX, int speedY) {
        this(locationX, locationY, speedX, speedY, BOSS_HP);
    }

    /**
     * 新增构造方法：允许自定义Boss血量
     * 困难模式用这个
     */
    public BossEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY, hp);
        this.maxHp = hp;

        // 绑定：环射策略
        this.shootStrategy = new CircleShootStrategy();
        this.direction = 1;
        this.power = 25;
    }

    @Override
    public void forward() {
        if (isFrozen()) {
            return;
        }

        locationX += speedX;

        if (locationX <= 0 || locationX >= Main.WINDOW_WIDTH) {
            speedX = -speedX;
        }
    }

    public int getMaxHp() {
        return maxHp;
    }
}