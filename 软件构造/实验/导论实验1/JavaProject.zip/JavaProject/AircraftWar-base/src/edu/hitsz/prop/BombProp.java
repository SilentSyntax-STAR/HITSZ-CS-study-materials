package edu.hitsz.prop;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.application.Game;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.observer.Observer;
import edu.hitsz.observer.Subject;

import java.util.LinkedList;
import java.util.List;

/**
 * 炸弹道具
 * 被观察者 Subject
 * 生效：通知所有敌机和敌机子弹
 */
public class BombProp extends AbstractProp implements Subject {

    private Game game;

    private List<Observer> observers = new LinkedList<>();

    public BombProp(int locationX, int locationY, int speedX, int speedY, Game game) {
        super(locationX, locationY, speedX, speedY);
        this.game = game;
    }

    @Override
    public void effect(HeroAircraft heroAircraft) {

        System.out.println("BombProp active! 观察者模式：通知敌机和敌机子弹");

        // 1. 注册敌机观察者
        for (AbstractAircraft enemy : game.getEnemyAircraft()) {
            if (!enemy.notValid()) {
                addObserver(enemy);
            }
        }

        // 2. 注册敌机子弹观察者
        for (BaseBullet bullet : game.getEnemyBullets()) {
            if (!bullet.notValid() && bullet instanceof Observer) {
                addObserver((Observer) bullet);
            }
        }

        // 3. 先加分，再通知消失
        game.addScoreByBomb();

        // 4. 通知所有观察者：炸弹来了
        notifyObservers("BOMB");

        // 5. 道具自身消失
        this.vanish();

        // 6. 播放炸弹音效
        playBombSound();
    }

    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String event) {
        for (Observer observer : observers) {
            observer.update(event);
        }
    }

    private void playBombSound() {
        try {
            javax.sound.sampled.AudioInputStream audio =
                    javax.sound.sampled.AudioSystem.getAudioInputStream(
                            new java.io.File("src/videos/bomb_explosion.wav")
                    );

            javax.sound.sampled.Clip clip =
                    javax.sound.sampled.AudioSystem.getClip();

            clip.open(audio);
            clip.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}