package edu.hitsz.aircraft;

import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.basic.AbstractFlyingObject;
import edu.hitsz.strategy.ShootStrategy;
import java.util.List;
import java.util.LinkedList;

import edu.hitsz.observer.Observer;

/**
 * 所有种类飞机的抽象父类（上下文角色）
 */
public abstract class AbstractAircraft extends AbstractFlyingObject implements Observer {
    protected int maxHp;
    protected int hp;
    protected boolean isFrozen = false;

    // === 策略模式核心：持有射击策略对象 ===
    protected ShootStrategy shootStrategy;
    // 射击方向（英雄机-1向上，敌机1向下）
    protected int direction;
    // 子弹威力
    protected int power;

    public AbstractAircraft(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY);
        this.hp = hp;
        this.maxHp = hp;
    }

    // === 策略模式：设置射击策略 ===
    public void setShootStrategy(ShootStrategy shootStrategy) {
        this.shootStrategy = shootStrategy;
    }

    // === 策略模式：委托策略执行射击 ===
    public List<BaseBullet> shoot() {
        if (isFrozen() || shootStrategy == null) {
            return new LinkedList<>();   // 冻结或不发射时返回空列表
        }
        return shootStrategy.shoot(this);
    }

    // 原有方法保留（不变）
    public void decreaseHp(int decrease) {
        hp -= decrease;
        if (hp <= 0) {
            hp = 0;
            vanish();
        }
    }

    public ShootStrategy getShootStrategy() {
        return this.shootStrategy;
    }

    public int getHp() { return hp; }
    public void setFrozen(boolean frozen) { isFrozen = frozen; }
    public boolean isFrozen() { return isFrozen; }
    public int getDirection() { return direction; }
    public void setDirection(int direction) { this.direction = direction; }
    public int getPower() { return power; }
    public void setPower(int power) { this.power = power; }
    public abstract void forward();

    @Override
    public void update(String event) {

        if ("BOMB".equals(event)) {

            /*
             * 炸弹效果：
             * 普通敌机、精英敌机、精英Plus、精英Pro直接消失
             * Boss 不直接消失，只扣一部分血，体现不同响应
             */
            if (this instanceof BossEnemy) {
                this.decreaseHp(100);
                System.out.println("Boss受到炸弹伤害，血量减少100");
            } else {
                this.vanish();
            }

        } else if ("FROZEN".equals(event)) {

            /*
             * 冰冻开始：
             * 敌机停止移动、停止射击
             */
            this.setFrozen(true);

        } else if ("UNFROZEN".equals(event)) {

            /*
             * 冰冻结束：
             * 恢复敌机行动
             */
            this.setFrozen(false);
        }
    }
}