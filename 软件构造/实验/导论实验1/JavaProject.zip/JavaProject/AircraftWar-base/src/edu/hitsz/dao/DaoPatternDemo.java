package edu.hitsz.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DaoPatternDemo {
    public static void main(String[] args) {
        ScoreRecordDao dao = new ScoreRecordDaoImpl("data/demo_record.txt");

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        dao.doAdd(new ScoreRecord(1, "Alice", 1200, LocalDateTime.now().format(formatter)));
        dao.doAdd(new ScoreRecord(2, "Bob", 900, LocalDateTime.now().format(formatter)));
        dao.doAdd(new ScoreRecord(3, "Cindy", 1500, LocalDateTime.now().format(formatter)));

        dao.sortRecords();
        dao.save();

        System.out.println("===== 排行榜 =====");
        for (ScoreRecord record : dao.getAllRecords()) {
            System.out.println(record.getRank() + "  "
                    + record.getPlayerName() + "  "
                    + record.getScore() + "  "
                    + record.getTime());
        }
    }
}