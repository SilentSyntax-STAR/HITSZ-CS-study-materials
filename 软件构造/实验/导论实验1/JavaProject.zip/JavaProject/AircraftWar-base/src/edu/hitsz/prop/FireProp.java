package edu.hitsz.prop;

import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.strategy.ScatterShootStrategy;

public class FireProp extends AbstractProp {

    private static final int DURATION = 3000;

    public FireProp(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }

    @Override
    public void effect(HeroAircraft heroAircraft) {
        playSupplySound();

        System.out.println("FireProp active! 切换为散射弹道");

        heroAircraft.activateShootStrategy(new ScatterShootStrategy(), DURATION);
        this.vanish();
    }
}
