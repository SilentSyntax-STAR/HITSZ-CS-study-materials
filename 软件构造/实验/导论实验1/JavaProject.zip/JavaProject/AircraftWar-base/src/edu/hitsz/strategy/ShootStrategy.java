package edu.hitsz.strategy;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.bullet.BaseBullet;
import java.util.List;

/**
 * 射击策略接口（抽象策略角色）
 * 定义所有弹道的统一执行方法
 */
public interface ShootStrategy {
    /**
     * 射击方法
     * @param aircraft 执行射击的飞机
     * @return 子弹列表
     */
    List<BaseBullet> shoot(AbstractAircraft aircraft);
}