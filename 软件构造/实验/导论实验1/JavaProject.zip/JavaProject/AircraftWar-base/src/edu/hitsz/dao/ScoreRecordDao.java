package edu.hitsz.dao;

import java.util.List;

public interface ScoreRecordDao {
    List<ScoreRecord> getAllRecords();
    void doAdd(ScoreRecord record);
    void doDelete(int index);
    ScoreRecord findByPlayerName(String playerName);
    void sortRecords();
    void save();
}