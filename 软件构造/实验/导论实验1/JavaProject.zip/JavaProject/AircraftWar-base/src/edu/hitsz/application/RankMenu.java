package edu.hitsz.application;

import edu.hitsz.dao.ScoreRecord;
import edu.hitsz.dao.ScoreRecordDao;
import edu.hitsz.dao.ScoreRecordDaoImpl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class RankMenu {
    private JPanel mainPanel;
    private JLabel titleLabel;
    private JScrollPane tableScrollPane;
    private JTable scoreTable;
    private JButton deleteButton;
    private JButton closeButton;

    private DefaultTableModel model;
    private String fileName;
    private ScoreRecordDao dao;

    public RankMenu(String fileName) {
        this.fileName = fileName;
        this.dao = new ScoreRecordDaoImpl(fileName);

        mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        titleLabel = new JLabel("排行榜", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 22));

        scoreTable = new JTable();
        tableScrollPane = new JScrollPane(scoreTable);

        deleteButton = new JButton("删除");
        closeButton = new JButton("关闭");

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.add(closeButton);
        buttonPanel.add(deleteButton);

        mainPanel.add(titleLabel, BorderLayout.NORTH);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        titleLabel.setText("排行榜");

        model = new DefaultTableModel(
                new Object[][]{},
                new String[]{"名次", "玩家", "得分", "时间"}
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        scoreTable.setModel(model);
        tableScrollPane.setViewportView(scoreTable);

        loadTableData();

        deleteButton.addActionListener(e -> deleteSelectedRecord());

        closeButton.addActionListener(e ->
                SwingUtilities.getWindowAncestor(mainPanel).dispose()
        );
    }

    private void loadTableData() {
        model.setRowCount(0);

        dao.sortRecords();
        List<ScoreRecord> records = dao.getAllRecords();

        for (ScoreRecord record : records) {
            model.addRow(new Object[]{
                    record.getRank(),
                    record.getPlayerName(),
                    record.getScore(),
                    record.getTime()
            });
        }
    }

    private void deleteSelectedRecord() {
        int row = scoreTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(mainPanel, "请先选中一条记录！");
            return;
        }

        int result = JOptionPane.showConfirmDialog(
                mainPanel,
                "确定删除这条记录吗？",
                "删除确认",
                JOptionPane.YES_NO_OPTION
        );

        if (result != JOptionPane.YES_OPTION) {
            return;
        }

        dao.sortRecords();
        List<ScoreRecord> records = dao.getAllRecords();

        if (row >= 0 && row < records.size()) {
            records.remove(row);
            dao.save();
            loadTableData();
        }
    }

    public JPanel getMainPanel() {
        return mainPanel;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("排行榜");
        frame.setContentPane(new RankMenu("data/record_easy.txt").getMainPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 500);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
