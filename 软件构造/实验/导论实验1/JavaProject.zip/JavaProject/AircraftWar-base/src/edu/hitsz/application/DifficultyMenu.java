package edu.hitsz.application;

import javax.swing.*;
import java.awt.*;

public class DifficultyMenu {
    private JPanel mainPanel;
    private JPanel centerPanel;
    private JButton easyButton;
    private JButton normalButton;
    private JButton hardButton;

    public DifficultyMenu() {
        mainPanel = new JPanel(new GridBagLayout());
        centerPanel = new JPanel(new GridLayout(3, 1, 0, 20));

        easyButton = new JButton("简单模式");
        normalButton = new JButton("正常模式");
        hardButton = new JButton("困难模式");

        Dimension buttonSize = new Dimension(180, 50);
        easyButton.setPreferredSize(buttonSize);
        normalButton.setPreferredSize(buttonSize);
        hardButton.setPreferredSize(buttonSize);

        centerPanel.add(easyButton);
        centerPanel.add(normalButton);
        centerPanel.add(hardButton);
        mainPanel.add(centerPanel);

        easyButton.addActionListener(e -> startGame(Difficulty.EASY));
        normalButton.addActionListener(e -> startGame(Difficulty.NORMAL));
        hardButton.addActionListener(e -> startGame(Difficulty.HARD));
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("选择难度");
        frame.setContentPane(new DifficultyMenu().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public JPanel getMainPanel() {
        return mainPanel;
    }

    private void startGame(Difficulty difficulty) {

        JFrame frame = new JFrame("Aircraft War");
        frame.setSize(Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Game game;

        switch(difficulty){

            case EASY:
                game = new EasyGame();
                break;

            case NORMAL:
                game = new NormalGame();
                break;

            default:
                game = new HardGame();

        }
        frame.add(game);

        frame.setVisible(true);
        game.action();

        // 关闭当前菜单窗口（关键！）
        SwingUtilities.getWindowAncestor(mainPanel).dispose();
    }
}
