package edu.hitsz.aircraft;

/**
 * 敌机工厂接口（实验二要求：工厂方法模式）
 */
public interface EnemyFactory {
    // 工厂方法：创建敌机
    AbstractAircraft createEnemy(int locationX, int locationY);
}