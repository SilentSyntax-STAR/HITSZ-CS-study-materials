package edu.hitsz.aircraft;

import edu.hitsz.application.Main;
import edu.hitsz.strategy.ScatterShootStrategy;

public class EliteProEnemy extends AbstractAircraft {
    private int moveSpeed = 8;

    public EliteProEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY, hp);
        // 绑定：散射策略
        this.shootStrategy = new ScatterShootStrategy();
        this.direction = 1;
        this.power = 20;
    }

    @Override
    public void forward() {
        if (isFrozen()) return;
        locationX += speedX;
        locationY += moveSpeed;
        if (locationX <= 0 || locationX >= Main.WINDOW_WIDTH) speedX = -speedX;
        if (locationY >= Main.WINDOW_HEIGHT) vanish();
    }
}