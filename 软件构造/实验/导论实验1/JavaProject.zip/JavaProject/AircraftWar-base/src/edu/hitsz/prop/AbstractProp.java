package edu.hitsz.prop;

import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.basic.AbstractFlyingObject;
import edu.hitsz.application.Main;
import edu.hitsz.application.SoundPlayer;

/**
 * 所有道具的抽象父类
 * 继承飞行物，定义道具生效抽象方法
 */
public abstract class AbstractProp extends AbstractFlyingObject {
    //构造方法
    public AbstractProp(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }

    @Override
    public void forward() {
        super.forward();
        // 道具向下移动，出界消失
        if (locationY >= Main.WINDOW_HEIGHT) {
            vanish();
        }
    }

    /**
     * 道具生效抽象方法
     * 不同道具实现不同生效逻辑
     * @param heroAircraft 英雄机（道具作用对象）
     */
    public abstract void effect(HeroAircraft heroAircraft);
    protected void playSupplySound() {
        SoundPlayer.playOnce("src/videos/get_supply.wav");
    }

}