package edu.hitsz.aircraft;

import edu.hitsz.application.Main;
import edu.hitsz.strategy.NoShootStrategy;

public class MobEnemy extends AbstractAircraft {
    public MobEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY, hp);
        // 绑定：不射击策略
        this.shootStrategy = new NoShootStrategy();
        this.direction = 1;
        this.power = 0;
    }

    @Override
    public void forward() {
        if (isFrozen()) {
            return;
        }

        locationX += speedX;
        locationY += speedY;
        if (locationY >= Main.WINDOW_HEIGHT) vanish();
    }
}
