package edu.hitsz.aircraft;

import edu.hitsz.strategy.DirectShootStrategy;
import edu.hitsz.strategy.ShootStrategy;

import java.util.Timer;
import java.util.TimerTask;

/**
 * 英雄机（单例模式）
 */
public class HeroAircraft extends AbstractAircraft {
    private volatile static HeroAircraft instance;
    private int shootStrategyVersion = 0;

    // 单例私有化构造
    private HeroAircraft(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY, hp);
        // 默认：直射策略
        this.shootStrategy = new DirectShootStrategy();
        this.direction = -1; // 向上射击
        this.power = 30;
    }

    // 单例获取
    public static HeroAircraft getInstance(int locationX, int locationY, int speedX, int speedY, int hp) {
        if (instance == null) {
            synchronized (HeroAircraft.class) {
                if (instance == null) {
                    instance = new HeroAircraft(locationX, locationY, speedX, speedY, hp);
                }
            }
        }
        return instance;
    }

    public static void resetInstance() { instance = null; }

    @Override
    public void forward() {} // 鼠标控制，不移动

    // 血量设置
    public void setHp(int hp) { this.hp = Math.min(hp, this.maxHp); }

    public synchronized void activateShootStrategy(ShootStrategy strategy, long durationMillis) {
        shootStrategyVersion++;
        int currentVersion = shootStrategyVersion;
        setShootStrategy(strategy);

        new Timer(true).schedule(new TimerTask() {
            @Override
            public void run() {
                synchronized (HeroAircraft.this) {
                    if (currentVersion == shootStrategyVersion) {
                        setShootStrategy(new DirectShootStrategy());
                        System.out.println("火力道具效果结束，恢复直射弹道");
                    }
                }
            }
        }, durationMillis);
    }
}
