package edu.hitsz.aircraft;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.MobEnemy;

/**
 * 普通敌机工厂
 */
public class MobEnemyFactory implements EnemyFactory {
    @Override
    public AbstractAircraft createEnemy(int locationX, int locationY) {
        // 注意：这里的参数要根据你的MobEnemy构造函数来，通常是 (x, y, speedX, speedY, hp)
        // 如果你不确定，就写 new MobEnemy(locationX, locationY, 0, 10, 30);
        return new MobEnemy(locationX, locationY, 0, 7, 20);
    }
}