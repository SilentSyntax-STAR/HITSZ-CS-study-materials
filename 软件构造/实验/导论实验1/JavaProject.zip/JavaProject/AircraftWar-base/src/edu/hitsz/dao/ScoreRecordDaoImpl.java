package edu.hitsz.dao;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 排行榜 DAO 实现类
 * 使用文件作为数据源
 */
public class ScoreRecordDaoImpl implements ScoreRecordDao {

    private final List<ScoreRecord> records = new ArrayList<>();
    private final String fileName;

    public ScoreRecordDaoImpl(String fileName) {
        this.fileName = fileName;
        loadFromFile();
    }

    /**
     * 从文件加载数据
     */
    private void loadFromFile() {
        File file = new File(fileName);

        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) {
                boolean created = parent.mkdirs();
                if (!created) {
                    System.out.println("目录已存在或创建失败：" + parent.getPath());
                }
            }

            if (!file.exists()) {
                boolean created = file.createNewFile();
                if (!created) {
                    System.out.println("文件已存在或创建失败：" + fileName);
                }
                return;
            }

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {

                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().isEmpty()) {
                        continue;
                    }

                    String[] parts = line.split(",", 4);
                    if (parts.length == 4) {
                        int rank = Integer.parseInt(parts[0]);
                        String playerName = parts[1];
                        int score = Integer.parseInt(parts[2]);
                        String time = parts[3];
                        records.add(new ScoreRecord(rank, playerName, score, time));
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.out.println("读取排行榜文件失败：" + fileName);
            System.out.println(e.getMessage());
        }
    }

    @Override
    public List<ScoreRecord> getAllRecords() {
        return records;
    }

    @Override
    public void doAdd(ScoreRecord record) {
        records.add(record);
    }

    @Override
    public void doDelete(int index) {
        if (index >= 0 && index < records.size()) {
            records.remove(index);
            updateRanks();
        } else {
            System.out.println("删除失败：索引越界");
        }
    }

    @Override
    public ScoreRecord findByPlayerName(String playerName) {
        for (ScoreRecord record : records) {
            if (record.getPlayerName().equals(playerName)) {
                return record;
            }
        }
        return null;
    }

    @Override
    public void sortRecords() {
        records.sort(Comparator.comparingInt(ScoreRecord::getScore).reversed());
        updateRanks();
    }

    @Override
    public void save() {
        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(fileName), StandardCharsets.UTF_8))) {

            for (ScoreRecord record : records) {
                writer.write(record.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("保存排行榜文件失败：" + fileName);
            System.out.println(e.getMessage());
        }
    }

    /**
     * 排序或删除后重新更新名次
     */
    private void updateRanks() {
        for (int i = 0; i < records.size(); i++) {
            records.get(i).setRank(i + 1);
        }
    }
}