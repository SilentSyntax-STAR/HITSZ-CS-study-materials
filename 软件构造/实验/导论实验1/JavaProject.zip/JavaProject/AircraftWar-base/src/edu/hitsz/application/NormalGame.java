package edu.hitsz.application;

public class NormalGame extends Game{

    public NormalGame(){
        super(Difficulty.NORMAL);
    }

}