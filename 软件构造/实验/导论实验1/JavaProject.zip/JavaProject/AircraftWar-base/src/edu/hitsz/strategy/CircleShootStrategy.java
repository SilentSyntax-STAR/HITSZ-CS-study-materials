package edu.hitsz.strategy;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;
import edu.hitsz.bullet.HeroBullet;
import java.util.LinkedList;
import java.util.List;

/**
 * 环射策略（Boss敌机、英雄机超级火力道具专用）
 * 英雄机：向上扇形（无身后子弹）
 * Boss敌机：向下扇形
 */
public class CircleShootStrategy implements ShootStrategy {
    @Override
    public List<BaseBullet> shoot(AbstractAircraft aircraft) {
        List<BaseBullet> res = new LinkedList<>();
        int x = aircraft.getLocationX();
        int y = aircraft.getLocationY() + aircraft.getDirection() * 30;
        int power = aircraft.getPower();
        int direction = aircraft.getDirection();

        int bulletCount = 20;
        double totalAngle = Math.toRadians(120); // 扇形总角度 120°
        double startAngle = -totalAngle / 2;     // 起始角度（弧度）
        double endAngle = totalAngle / 2;        // 结束角度
        int baseSpeed = 8;                       // 子弹速度大小

        for (int i = 0; i < bulletCount; i++) {
            double t = (double) i / (bulletCount - 1);
            double angle = startAngle + t * (endAngle - startAngle);
            int speedX = (int) (baseSpeed * Math.sin(angle));
            int speedY;

            if (direction == -1) {
                // 英雄机：向上射击，速度Y为负
                speedY = (int) (baseSpeed * -Math.cos(angle));
                res.add(new HeroBullet(x, y, speedX, speedY, power));
            } else {
                // 敌机：向下射击，速度Y为正
                speedY = (int) (baseSpeed * Math.cos(angle));
                res.add(new EnemyBullet(x, y, speedX, speedY, power));
            }
        }
        return res;
    }
}
