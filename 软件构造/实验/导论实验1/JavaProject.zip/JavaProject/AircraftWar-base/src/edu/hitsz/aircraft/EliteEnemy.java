package edu.hitsz.aircraft;

import edu.hitsz.application.Main;
import edu.hitsz.strategy.DirectShootStrategy;

public class EliteEnemy extends AbstractAircraft {
    public EliteEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY, hp);
        // 绑定：直射策略
        this.shootStrategy = new DirectShootStrategy();
        this.direction = 1;
        this.power = 10;
    }

    @Override
    public void forward() {
        if (isFrozen()) {
            return;
        }

        locationX += speedX;
        locationY += speedY;
        if (locationY >= Main.WINDOW_HEIGHT) vanish();
    }
}
