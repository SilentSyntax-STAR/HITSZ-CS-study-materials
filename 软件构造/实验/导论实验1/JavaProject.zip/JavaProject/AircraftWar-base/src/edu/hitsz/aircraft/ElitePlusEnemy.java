package edu.hitsz.aircraft;

import edu.hitsz.application.Main;
import edu.hitsz.strategy.DoubleDirectShootStrategy;

public class ElitePlusEnemy extends AbstractAircraft {
    private int moveThreshold = 0;

    public ElitePlusEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY, hp);
        // 绑定：双排直射策略
        this.shootStrategy = new DoubleDirectShootStrategy();
        this.direction = 1;
        this.power = 15;
    }

    @Override
    public void forward() {
        if (isFrozen()) return;
        moveThreshold++;
        if (moveThreshold >= 20) {
            speedX = -speedX;
            moveThreshold = 0;
        }
        locationX += speedX;
        locationY += speedY;
        if (locationX <= 0 || locationX >= Main.WINDOW_WIDTH) speedX = -speedX;
        if (locationY >= Main.WINDOW_HEIGHT) vanish();
    }
}