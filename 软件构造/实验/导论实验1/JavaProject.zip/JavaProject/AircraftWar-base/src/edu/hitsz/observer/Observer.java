package edu.hitsz.observer;

public interface Observer {

    /**
     * 接收被观察者通知
     * @param event 事件类型，例如 BOMB、FROZEN、UNFROZEN
     */
    void update(String event);
}