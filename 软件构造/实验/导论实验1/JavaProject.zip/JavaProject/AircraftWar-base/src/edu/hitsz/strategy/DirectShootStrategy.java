package edu.hitsz.strategy;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;
import edu.hitsz.bullet.HeroBullet;
import java.util.LinkedList;
import java.util.List;

/**
 * 直射策略（英雄机默认、精英敌机专用）
 */
public class DirectShootStrategy implements ShootStrategy {
    @Override
    public List<BaseBullet> shoot(AbstractAircraft aircraft) {
        List<BaseBullet> res = new LinkedList<>();
        int x = aircraft.getLocationX();
        int y = aircraft.getLocationY() + aircraft.getDirection() * 20;
        int speedY;
        int power = aircraft.getPower();

        // 区分英雄机/敌机子弹
        if (aircraft.getDirection() == -1) {
            speedY = aircraft.getSpeedY() + aircraft.getDirection() * 10;
            res.add(new HeroBullet(x, y, 0, speedY, power));
        } else {
            speedY = aircraft.getSpeedY() + aircraft.getDirection() * 8;
            res.add(new EnemyBullet(x, y, 0, speedY, power));
        }
        return res;
    }
}