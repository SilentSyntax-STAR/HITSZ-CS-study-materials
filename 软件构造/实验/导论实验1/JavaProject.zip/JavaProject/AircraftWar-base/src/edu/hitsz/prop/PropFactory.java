package edu.hitsz.prop;

import edu.hitsz.application.Game;
import edu.hitsz.prop.AbstractProp;
import edu.hitsz.prop.BloodProp;
import edu.hitsz.prop.FireProp;
import edu.hitsz.prop.FirePlusProp;
import edu.hitsz.prop.BombProp;
import edu.hitsz.prop.FrozenProp;

/**
 * 道具简单工厂（实验二要求：简单工厂模式）
 * 统一创建所有道具对象
 */
public class PropFactory {

    // 静态工厂方法：根据类型创建对应道具
    public static AbstractProp createProp(String propType, int x, int y, int speedX, int speedY, Game game) {
        if ("BLOOD".equals(propType)) {
            return new BloodProp(x, y, speedX, speedY);
        } else if ("FIRE".equals(propType)) {
            return new FireProp(x, y, speedX, speedY);
        } else if ("FIRE_PLUS".equals(propType)) {
            return new FirePlusProp(x, y, speedX, speedY);
        } else if ("BOMB".equals(propType)) {
            return new BombProp(x, y, speedX, speedY, game);
        } else if ("FROZEN".equals(propType)) {
            return new FrozenProp(x, y, speedX, speedY, game);
        } else {
            // 默认返回血包
            return new BloodProp(x, y, speedX, speedY);
        }
    }
}