package edu.hitsz.prop;

import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.strategy.CircleShootStrategy;

public class FirePlusProp extends AbstractProp {

    private static final int DURATION = 3000;

    public FirePlusProp(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }

    @Override
    public void effect(HeroAircraft heroAircraft) {
        playSupplySound();

        System.out.println("FirePlusProp active! 切换为环射弹道");

        heroAircraft.activateShootStrategy(new CircleShootStrategy(), DURATION);
        this.vanish();
    }
}
