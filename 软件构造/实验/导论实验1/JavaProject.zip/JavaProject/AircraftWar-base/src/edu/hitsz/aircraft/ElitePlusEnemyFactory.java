package edu.hitsz.aircraft;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.ElitePlusEnemy;

/**
 * 精锐敌机工厂
 */
public class ElitePlusEnemyFactory implements EnemyFactory {
    @Override
    public AbstractAircraft createEnemy(int locationX, int locationY) {
        return new ElitePlusEnemy(locationX, locationY, 2, 7, 60);
    }
}