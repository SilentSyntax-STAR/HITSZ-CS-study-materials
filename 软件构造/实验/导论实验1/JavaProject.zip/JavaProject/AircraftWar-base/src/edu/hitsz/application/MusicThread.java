package edu.hitsz.application;

import javax.sound.sampled.*;
import java.io.File;

public class MusicThread extends Thread {

    private final String filename;
    private Clip clip;

    public MusicThread(String filename) {
        this.filename = filename;
    }

    public void stopMusic() {
        try {
            if (clip != null) {
                clip.stop();
                clip.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            AudioInputStream audioInputStream =
                    AudioSystem.getAudioInputStream(new File(filename));

            clip = AudioSystem.getClip();
            clip.open(audioInputStream);

            // 循环播放
            clip.loop(Clip.LOOP_CONTINUOUSLY);
            clip.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}