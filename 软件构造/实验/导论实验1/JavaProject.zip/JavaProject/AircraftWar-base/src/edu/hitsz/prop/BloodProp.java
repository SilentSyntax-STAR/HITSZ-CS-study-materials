package edu.hitsz.prop;

import edu.hitsz.aircraft.HeroAircraft;

/**
 * 加血道具
 * 生效：英雄机回血，不超过最大血量
 */
public class BloodProp extends AbstractProp {
    // 加血值（实验一设定为50）
    private static final int BLOOD_ADD = 50;

    public BloodProp(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }

    @Override
    public void effect(HeroAircraft heroAircraft) {
        // 回血：当前血量+50，不超过最大血量
        playSupplySound();
        heroAircraft.setHp(heroAircraft.getHp() + BLOOD_ADD);
        System.out.println("BloodProp active! 加血" + BLOOD_ADD + "，当前血量：" + heroAircraft.getHp());
    }
}