package edu.hitsz.application;

public class EasyGame extends Game{

    public EasyGame(){
        super(Difficulty.EASY);
    }

    @Override
    protected void difficultyUpgrade(){
        //简单模式不升级
    }

    @Override
    protected void spawnBoss(){
        //简单模式没Boss
    }
}