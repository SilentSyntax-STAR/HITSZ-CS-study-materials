package Reflect;
import java.lang.reflect.Field;

public class FieldTest {
    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {
        Student Harry = new Student("Harry Potter", 11);
        Class<?> StudentClass = Harry.getClass();
        Field f = StudentClass.getDeclaredField("name"); //"age"
        f.setAccessible(true); // 去除私有权限
        Object v1 = f.get(Harry); // 获取成员变量
        System.out.println(v1);
        f.set(Harry,"the boy who lived"); //13
        System.out.println(Harry.getName()); //getAge()
    }
}
