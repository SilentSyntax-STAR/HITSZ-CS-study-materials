package Reflect;
public class forNameTest {
    public static void main(String[] args) throws ClassNotFoundException {
        String className = "Reflect.Student";
        Class<?> cl1 = Class.forName(className); //Class.forName
        System.out.println(cl1);

        //也可以反射接口信息
        Class<?> cl2 = Class.forName("Generic.ShowInterface");
        System.out.println(cl2);
        //也可反射抽象类信息
        Class<?> cl3 = Class.forName("TemplateMethod.MilkTea");
        System.out.println(cl3);

      //  Class<?> cl2 = Student.class; //T.class
        Class<?> cl4 = int.class; //Integer.class
        System.out.println(cl4);

        //也可以反射接口信息
        Class<?> cl5 = Generic.ShowInterface.class;
        System.out.println(cl5);
        //也可以反射抽象类信息
        Class<?> cl6 = TemplateMethod.MilkTea.class;
        System.out.println(cl6);
    }
}
