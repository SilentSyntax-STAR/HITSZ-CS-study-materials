package TemplateMethod;

public class RedBeanMilkTea extends MilkTea {

    @Override
    void addCondiments() {
        System.out.println("第二步：加入上好的红豆");
    }

    @Override
    void addMilkCover() {
        System.out.println("第四步：加上榴莲奶盖");
    }

}