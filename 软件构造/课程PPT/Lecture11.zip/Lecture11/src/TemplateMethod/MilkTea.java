package TemplateMethod;

public abstract class MilkTea {

    //模板方法, make, 模板方法可以做成final , 不让子类去覆盖.
    final void make() {
        select();
        /*我们加入了一个条件语句，而该条件是否成立，
        是有一个具体的方法决定的（customerWantCondiments(),
        如果是需要加料的奶茶，才调用addCondiments()）*/
        if(customerWantCondiments()) {
            addCondiments(); //钩子方法
        }
        stir();
        if(customerWantMilkCover()) {
            addMilkCover(); //钩子方法
        }
        express();

    }

    //选材料
    void select() {
        System.out.println("第一步：选择上好的奶和茶");
    }

    //添加不同的配料， 抽象方法, 子类具体实现
    abstract void addCondiments();

    //搅拌
    void stir() {
        System.out.println("第三步：进行搅拌");
    }

    abstract void addMilkCover();

    void express() {
        System.out.println("第五步：包装好快递给客户");
    }

    //钩子方法，决定是否需要添加配料
    boolean customerWantCondiments() {
        return true;
    }
    boolean customerWantMilkCover() {
        return true;
    }
}