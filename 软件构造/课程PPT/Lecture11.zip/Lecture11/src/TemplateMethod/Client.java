package TemplateMethod;

public class Client {

    public static void main(String[] args) {
        System.out.println("----制作红豆奶茶----");
        MilkTea RedBeanMilkTea = new RedBeanMilkTea();
        RedBeanMilkTea.make();

        System.out.println("----制作纯奶茶----");
        MilkTea PureMilkTea = new PureMilkTea();
        PureMilkTea.make();
    }

}