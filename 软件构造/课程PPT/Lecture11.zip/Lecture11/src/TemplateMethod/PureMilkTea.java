package TemplateMethod;

public class PureMilkTea extends MilkTea{

    @Override
    void addCondiments() {
        //空实现
    }

    @Override
    boolean customerWantCondiments() {
        return false;
    }

    @Override
    void addMilkCover() {
        //空实现
    }

    @Override
    boolean customerWantMilkCover() {
        return false;
    }

}