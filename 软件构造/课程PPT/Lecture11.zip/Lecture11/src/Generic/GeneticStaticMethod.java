package Generic;

public class GeneticStaticMethod<K> {
    private K k;
    public GeneticStaticMethod(K k){
        this.k=k;
    }
    public static <T> void fun1(T t){
  //public static void fun1(K k){
        System.out.println(t);
    }

}
