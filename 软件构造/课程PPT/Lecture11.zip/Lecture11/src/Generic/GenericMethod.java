package Generic;

public class GenericMethod {
    public <T> void sampleMethod(T[] array) {
        for (T t : array) {
            System.out.println(t);
        }
    }
    public static void main(String[] args) {
        GenericMethod obj = new GenericMethod();
        //下面声明数组时是否可以改为int？
        Integer [] intArray = {1, 2, 3, 4}; // 声明泛型不能使用基本数据类型
        obj.sampleMethod(intArray);

        String[] stringArray = {"Harry", "Ron", "Hermione"};
        obj.sampleMethod(stringArray);
    }
}