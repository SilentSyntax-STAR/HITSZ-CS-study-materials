package Generic;

import java.util.ArrayList;

public class GenericTest {
    public static void main(String[] args) {
        ArrayList list = new ArrayList();//无泛型
        list.add("str");
        list.add(100);
        list.add(true);
        System.out.println(list.size());

        String str0 = (String)list.get(1); // 运行时报错
     //   Object str0 = list.get(1);
        System.out.println(str0);


        ArrayList<String> list2 = new ArrayList<>();
        list2.add("str");
       // list2.add(100); //编译时报错
        String str1 = list2.get(0); //无需强制转型


    }
}
