package SocketTest;

import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        BufferedReader br = null;
        String clientStr="";
        try {
            //创建一个监听的端口
            ServerSocket ss = new ServerSocket(1234);
            System.out.println("服务器启动...");
            //等待接受客户端通信请求，并建立专用通信端口
            Socket s = ss.accept(); //每当有新的客户端连接进来后，就返回一个Socket实例
            System.out.println("有客户端发送请求");
            Send send = new Send(s); //可能有多个客户端，每个socket创建一个新线程任务来处理
            Thread t1 = new Thread(send); //创建线程任务
            t1.start(); //开启新线程
            while(true){

                //获取客户端通信的信息，并读出来
                br = new BufferedReader(new InputStreamReader(s.getInputStream()));
                clientStr = br.readLine();
                System.out.println("客户端："+clientStr);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
