package SocketTest;

import java.io.*;
import java.net.*;
import java.util.*;


public class Send implements Runnable{//用来捕获输入输出流
    Socket s ;

    //捕获键盘输入流
    Scanner in = new Scanner(System.in); //第一种方式
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); //第二种方式
    public Send(Socket s){
        this.s = s;
    }
    public void run() { // 输出流
        // TODO Auto-generated method stub
        PrintWriter out = null;
        try {
            while(true){
                out = new PrintWriter(new OutputStreamWriter(s.getOutputStream()),true);
                String str = in.nextLine();
              //  String str = br.readLine();
                out.println(str);

            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally{
            out.close();
        }

    }
}
