public class Person2 {
    private String name;
    private int age;

    public Person2(String name, int age) {
        name = name; // 无this会导致赋值失败
        age = age; // 无this会导致赋值失败
    }

    public void tell() {   // 表示一个功能
        System.out.println("姓名:" + name + "，年龄:" + age);
    }
}