public class Main2 {
    public static void main(String[] args) {
        Person2 per = new Person2("zhangsan",15);
        per.tell();
    }
}
