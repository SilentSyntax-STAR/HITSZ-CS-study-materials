public class Test3{
    public static void main(String[] args) {
        System.out.println(cnt);
    }
    static int cnt=6;
    static{
        cnt+=9;
    }
    static{
        cnt/=3;
    }
}
