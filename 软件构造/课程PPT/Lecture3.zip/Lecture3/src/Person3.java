public class Person3 {
    private String name;
    private int age;

    public void tell() {   // 表示一个功能
        System.out.println("姓名:" + name + "，年龄:" + age);
    }

    public void fun() {
        System.out.println("当前对象"+this);//指向自身的对象
    }
    public Person3() {
    }
    public Person3(String name) {
        this.name=name; //指向自身的一个对象
    }
    public Person3(String name, int age) {
        this(name); //设置name时可调用本类中的构造方法
        this.age=age; //调用本类属性,都是this.
        this.tell();//调用本类的方法,都是this.
    }
}
