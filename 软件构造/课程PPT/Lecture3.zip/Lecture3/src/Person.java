public class Person {
    String name;   // 不使用封装

     int age;       // 不使用封装


    /*public void setName(String n) {
        name = n;
    }
    public String getName() {
        return name;
    }
    public void setAge(int a) {
        // 合法年龄
        if (a >= 0 && a <= 150) {
            age = 18; // 18
        }
    }

    public int getAge() {
        return age;
        }
*/


    public void tell() {   // 表示一个功能
        System.out.println("姓名:" + name + "，年龄:" + age);

    }


}

