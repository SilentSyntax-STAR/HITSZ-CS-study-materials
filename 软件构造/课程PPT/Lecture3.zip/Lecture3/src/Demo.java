public class Demo {
    static int static_i = 7; // 定义静态成员变量
    int normal_i = 0; //定义成员变量

    public static void main(String[] args) {
        Demo de1 = new Demo(); // 创建对象1
        Demo de2 = new Demo(); // 创建对象2

        de1.normal_i = 100; // 修改 de1 的普通变量 normal_i 为 100

        de2.static_i = 50; // 修改 de2 的静态变量 static_i 为 50

        // 输出 de1 数据
        System.out.println("第一个实例对象变量static_i：" + de1.static_i);
        System.out.println("第一个实例对象变量normal_i：" + de1.normal_i);

        // 输出 de2 数据
        System.out.println("第二个实例对象变量static_i：" + de2.static_i);
        System.out.println("第二个实例对象变量normal_i：" + de2.normal_i);
    }
}

