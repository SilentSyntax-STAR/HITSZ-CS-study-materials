public class Main3 {
    public static void main(String[] args) {
        Person3 per1 = new Person3("zhangsan",15);
       // Person3 per2 = new Person3("lisi",17);

        per1.fun();
      //  per2.fun();
    }
}
