public class Main {
    public static void main(String[] args) {

       Person per = new Person();
        per.name = "张**";
        per.age = 33;
        per.tell();


       /* Person per = new Person();
        per.setName("张**");
        per.setAge(33);
        per.tell();*/



    }
}
