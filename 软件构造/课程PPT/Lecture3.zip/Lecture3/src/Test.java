public class Test {
    public Test(){//构造方法
        System.out.println("A的构造方法");
    }

    static {//静态代码块
        System.out.println("A的静态代码块");
    }

    {//初始化块
        System.out.println("A的初始化块");
    }

    public static void main(String[] args) {
     //   Test a = new Test();
     //   Test b = new Test();
    }
}
