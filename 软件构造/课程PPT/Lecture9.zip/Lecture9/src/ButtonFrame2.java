import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonFrame2 extends JFrame
{
    private JPanel buttonPanel;
    private static final int DEFAULT_WIDTH = 300;
    private static final int DEFAULT_HEIGHT = 200;

    public ButtonFrame2()
    {
        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        buttonPanel = new JPanel();
        add(buttonPanel);
        makeButton("yellow",Color.YELLOW);
        makeButton("blue",Color.BLUE);
        makeButton("red",Color.RED);
        makeButton("green",Color.GREEN);
    }
    public void makeButton(String name , Color backgroundColor)
    {
        JButton button=new JButton(name);//创建事件源
        buttonPanel.add(button);

        //第一种方式（lambda表达式）
       // button.addActionListener(event->buttonPanel.setBackground(backgroundColor));

        //第二种方式
        /*或者创建监听器的实例，里面的actionPerformed方法引用参数里的
        backgroundColor值。然后将按钮和监听器相关联。*/
         ColorAction action=new ColorAction(backgroundColor);//创建监听器对象
         button.addActionListener(action);//将按钮与监听器相关联
    }
    /**
     * An action listener that sets the panel's background color.
     */
    private class ColorAction implements ActionListener
    {
        private Color backgroundColor;
        public ColorAction(Color c)
        {
            backgroundColor = c;
        }
        public void actionPerformed(ActionEvent event)
        {
            buttonPanel.setBackground(backgroundColor);
        }
    }
}
