package MVC;

public class MVCDemo {
    public static void main(String[] args) {

        //从数据库里获取学生记录
        StudentModel model = retrieveStudentFromDatabase();

        //创建视图：把学生信息输出到控制台
        StudentView view = new StudentView();

        //创建控制器
        StudentController controller = new StudentController(model,view);

        //用户要求更新视图,由控制器通知
        controller.updateView();

        //用户要求更新数据，由控制器通知
        controller.setStudentName("Ron");
        //用户要求更新视图, 由控制器通知
        controller.updateView();
    }
    private static StudentModel retrieveStudentFromDatabase(){
            StudentModel student = new StudentModel();
            student.setName("Harry");
            student.setRollNo("10");
            return student;
        }
    }
