package MVC;

//封装了对数据的操作
public class StudentModel {
    private String rollNo;
    private String name;
    public String getRollNo(){
        return rollNo;
    }
    public void setRollNo(String rollNo){
        this.rollNo = rollNo;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
}
