import java.awt.*;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
public class JMenuDemo {
    public static void main(String[] agrs) {
        EventQueue.invokeLater(() ->
        {
            JFrame frame = new JFrame();    //创建Frame窗口
            JMenuBar menuBar = new JMenuBar(); //创建菜单栏
            frame.setJMenuBar(menuBar);  //将菜单栏放在窗体顶部
            JMenu fileMenu = new JMenu("File");
            fileMenu.setFont(new Font("楷体", Font.BOLD, 26));
            menuBar.add(fileMenu);
            JMenu editMenu = new JMenu("Edit");
            editMenu.setFont(new Font("楷体", Font.BOLD, 26));
            menuBar.add(editMenu);
            JMenuItem pasteItem = new JMenuItem("Paste");//
            pasteItem.setFont(new Font("楷体", Font.BOLD, 26));
            editMenu.add(pasteItem);
            editMenu.addSeparator();//增加分割线！！！
            JCheckBoxMenuItem readonlyItem = new JCheckBoxMenuItem("Read-only");
            readonlyItem.setFont(new Font("楷体", Font.BOLD, 26));
            JMenu optionMenu = new JMenu("Options");
            optionMenu.setFont(new Font("楷体", Font.BOLD, 26));
            optionMenu.add(readonlyItem);
            editMenu.add(optionMenu);
            frame.setBounds(300, 200, 400, 100);
            frame.setVisible(true);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        });
    }
}