import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;

public class ImageDisplay {
    public static void main(String[] args) {
        EventQueue.invokeLater(() ->
        {
            JFrame frame = new JFrame("Draw Image");
            frame.add(new JComponent() {
                @Override
                public void paintComponent(Graphics g) {

                    int X = 50;
                    int Y = 50;
                    Image image = new ImageIcon("Durian.jpeg").getImage();
                    g.drawImage(image, X, Y, null);
                }
            });
            frame.setPreferredSize(new Dimension(500, 400));
            frame.pack();
            frame.setVisible(true);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        });
    }
}
