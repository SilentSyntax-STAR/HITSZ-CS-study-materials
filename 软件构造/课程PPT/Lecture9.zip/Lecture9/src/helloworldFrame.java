import javax.swing.*;
import java.awt.*;

public class helloworldFrame {
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> // 事件派发线程
             {
                JFrame frame = new JFrame("Hello World");
                frame.add(new JComponent() {
                    @Override
                    public void paintComponent(Graphics g) { //设置Graphics 对象
                        g.setFont(new Font("宋体",Font.BOLD,25));
                        g.drawString("我爱哈工大", 200, 200);
                    }
                }, BorderLayout.CENTER);

                frame.setPreferredSize(new Dimension(500, 700));
                frame.pack();
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
        });
    }
}
