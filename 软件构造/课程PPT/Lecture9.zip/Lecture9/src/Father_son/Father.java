package Father_son;

class Father {
    static {
        System.out.println("1-父类静态代码块");
    }

    {
        System.out.println("3-父类初始化块");
    }

    Father() {
        System.out.println("4-父类构造方法");
    }
}
