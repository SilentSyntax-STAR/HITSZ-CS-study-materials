package Father_son;

public class Test {
    public static void main(String[] args) {
        new Son();  // 输出1-2-3-4-5-6
        new Son();  // 再次创建对象时，只输出3-4-5-6（静态块只执行一次）
    }
}
