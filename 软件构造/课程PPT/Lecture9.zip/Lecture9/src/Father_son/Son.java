package Father_son;

class Son extends Father {
    static {
        System.out.println("2-子类静态代码块");
    }

    {
        System.out.println("5-子类初始化块");
    }

    Son() {
        System.out.println("6-子类构造方法");
    }
}