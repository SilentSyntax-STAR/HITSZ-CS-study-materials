package Grandpa;

public class GrandParentClass {
    public void grandParentMethod() {
        System.out.println("调用了超级父类的方法");
    }
}

