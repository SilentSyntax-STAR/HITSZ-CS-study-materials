package Grandpa;

public class ChildClass extends ParentClass {
    public void childMethod() {
        // 调用父类的方法（从超级父类继承而来），间接调用了超级父类的方法
        super.grandParentMethod();
    }
}
