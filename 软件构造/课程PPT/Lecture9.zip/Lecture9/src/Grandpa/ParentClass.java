package Grandpa;

public class ParentClass extends GrandParentClass {
    // 父类不重写祖父类的方法，自动拥有祖父类的方法
    // 需要注意的是，如果ParentClass覆盖了GrandParentClass的方法，
    // 那么ChildClass将无法直接调用GrandParentClass的方法。
    // 在这种情况下，我们可以使用super关键字来调用ParentClass的方法，
    // 然后在ParentClass中再次调用GrandParentClass的方法。

 /*   @Override
    public void grandParentMethod() {
        super.grandParentMethod(); // 调用父类的方法
        System.out.println("调用了父类的方法");
    }*/




}
