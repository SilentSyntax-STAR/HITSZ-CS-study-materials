import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;

public class DrawRectangle {
    public static void main(String[] args) {
        EventQueue.invokeLater(() ->
        {
                JFrame frame = new JFrame("Draw Rectangle");
                frame.add(new JComponent() {
                    @Override
                    public void paintComponent(Graphics g) {
                        //获得Graphics2D类的一个对象
                        Graphics2D g2 = (Graphics2D) g;

                        g2.setPaint(Color.RED);
                        // 画红色矩形
                        // 使用Graphics2D类下的Rectangle2D绘制矩形
                        g2.draw(new Rectangle2D.Double(100, 100, 200, 150));

                        g2.setPaint(new Color(137,112,219));
                        // 画自定义颜色矩形
                        g2.fill(new Rectangle2D.Double(250, 50, 200, 250));
                    }
                }, BorderLayout.CENTER);

                frame.setPreferredSize(new Dimension(500, 400));
                frame.pack();
                frame.setVisible(true);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        });
    }
}
