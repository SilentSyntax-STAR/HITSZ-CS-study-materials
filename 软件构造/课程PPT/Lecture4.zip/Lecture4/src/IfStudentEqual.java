class IfStudentEqual {
    public static void main(String[] args) {
        // 创建两个对象
        Object Student_1 = new Student("Zhangsan",19);
        Object Student_2 = new Student("Lisi",18);

        // 不同对象，内存地址不同，不相等，返回 false
        System.out.println(Student_1.equals(Student_2));

        // 对象引用，内存地址相同，相等，返回 true
        Object Student_3 = Student_1;
        System.out.println(Student_1.equals(Student_3));

      //  Student_1.fun(); 不能调用子类的方法，指向的是Object



        Student Zhangsan = (Student)Student_1; //强制类型转换
        Zhangsan.fun();

        Student Lisi = (Student)Student_2;
        Lisi.fun();

        Student Zhangsan2 = (Student)Student_3;
        Zhangsan2.fun();


    }
}

