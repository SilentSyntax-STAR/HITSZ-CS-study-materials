public class Student {
    private String name;
    private int age;
    Student(String name, int age){
        this.name = name;
        this.age = age;
    }

    public void fun() {
        System.out.println("当前对象"+this);//指向自身的对象
    }
}
