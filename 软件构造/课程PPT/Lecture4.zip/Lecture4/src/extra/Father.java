package extra;
// 子类能不能继承父类的私有属性
public class Father {
    private int a;
    public Father(){

    }
    public Father(int a){
        this.a = a;
    }
    public int getA(){ //定义一个public 方法来获取私有属性
        return this.a;
    }
}




