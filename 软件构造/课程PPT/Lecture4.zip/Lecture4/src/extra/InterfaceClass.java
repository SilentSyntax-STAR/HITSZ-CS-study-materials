package extra;

public interface InterfaceClass {
    public static final int a = 1; // 静态属性
    public static void Func() { //静态方法
        System.out.println("interface");
    }
    public static void main(String[] args) {
        InterfaceClass.Func();
        System.out.println(InterfaceClass.a);
    }
}
