package extra;

// 抽象类可以有静态属性和方法
abstract class AbstractClass {
    public static int a = 1; // 静态属性
    public static void Func(){ //静态方法
        System.out.println("abstract class");


    }
    public static void main(String[] args) {
        AbstractClass.Func();
        System.out.println(AbstractClass.a);
    }
}
