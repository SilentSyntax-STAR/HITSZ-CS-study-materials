package extra;

// 子类能不能继承父类的私有属性
public class Children extends Father{
    int a;
    int b;
    public Children(){

    }
    public Children(int a,int b){
        super(a);//调用父类的构造方法,可以访问私有属性
        this.b = b;
    }
}
