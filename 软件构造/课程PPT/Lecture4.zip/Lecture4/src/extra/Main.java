package extra;

// 子类能不能继承父类的私有属性
public class Main {
    public static void main(String[] args) {
        Children child1 = new Children(11,12);
        System.out.println(child1.getA());//获得私有属性
    }
}
