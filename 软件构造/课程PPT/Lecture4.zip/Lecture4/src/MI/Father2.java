package MI;

public interface Father2 {
    public void strong();
}
