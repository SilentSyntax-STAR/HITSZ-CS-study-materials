package MI;

public class Son {
    // 内部类继承Father类
    class Father_Inner extends Father {
        public int strong() {
            return super.strong() + 1;
        }
    }
    // 内部类继承Mother类
    class Mother_Inner extends Mother {
        public int smart() {
            return super.smart() + 2;
        }
    }
    public int getStrong() {
        return new Father_Inner().strong();
    }
    public int getSmart() {
        return new Mother_Inner().smart();
    }
    public static void main(String[] args) {
        Son Nezha = new Son();
        System.out.println("哪吒的强壮指数"+Nezha.getStrong());
        System.out.println("哪吒的聪慧指数"+Nezha.getSmart());
    }
}
