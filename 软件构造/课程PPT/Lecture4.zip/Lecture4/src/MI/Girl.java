package MI;

public class Girl implements Daughter{

    @Override
    public void strong(){
        System.out.println("She’s not strong.");
    }
    @Override
    public void smart(){
        System.out.println("She’s very smart.");
    }
    @Override
    public void kind(){
        System.out.println("She’s very kind.");
    }

    public static void main(String[] args){
        Girl Tianluo = new Girl();
        Tianluo.strong();
        Tianluo.smart();
        Tianluo.kind();
    }
}

