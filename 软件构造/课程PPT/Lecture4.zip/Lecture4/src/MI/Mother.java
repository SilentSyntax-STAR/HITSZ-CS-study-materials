package MI;


public class Mother{
    public int smart(){
        // 聪慧指数
        return 8;
    }
}

