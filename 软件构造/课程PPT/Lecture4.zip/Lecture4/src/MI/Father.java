package MI;

public class Father{
    public int strong(){
        // 强壮指数
        return 9;
    }
}

