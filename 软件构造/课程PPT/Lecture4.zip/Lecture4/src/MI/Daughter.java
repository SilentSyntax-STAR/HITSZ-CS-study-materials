package MI;

public interface Daughter extends Father2,Mother2 {
    public void kind();
}
