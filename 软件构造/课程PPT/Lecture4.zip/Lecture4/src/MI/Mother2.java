package MI;

public interface Mother2 {
    public void smart();
}
