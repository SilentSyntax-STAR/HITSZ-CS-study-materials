package poly;
public class Engineer extends Person{
    @Override
    public void getTarget(){
        System.out.println("技术改变世界");
    }
}

