package poly;
public class Scientist extends Person{
    @Override
    public void getTarget(){
        System.out.println("勇攀科学高峰");
    }
}

