package poly;
public interface GetTarget {
    void getTarget();
}
