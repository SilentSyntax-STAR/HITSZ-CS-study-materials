package poly;
public class Student extends Person {
    @Override
    public void getTarget() {
        System.out.println("功夫到家");
    }

    public static void show2_target() {
        System.out.print(" student 目标 ");
    }
}



