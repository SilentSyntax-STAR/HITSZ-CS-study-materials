package poly;
public class Talent implements GetTarget{
@Override
public void getTarget(){
        System.out.println("打造国之重器");
        }
}

