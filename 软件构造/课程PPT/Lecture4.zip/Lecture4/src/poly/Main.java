package poly;


public class Main {//重写
    public static void main(String[] args) {
        Person P1 = new Student();
        P1.getTarget();
        P1.show_target();
        Person P2 = new Teacher();
        P2.getTarget();
    }
}




/*
public class Main {//抽象类
    public static void main(String[] args) {
        Person P1 = new Engineer();
        P1.getTarget();
        Person P2 = new Scientist();
        P2.getTarget();
    }
}

 */





/*public class Main {//接口
    public static void main(String[] args) {
        GetTarget  Zhang= new Talent();
        Zhang.getTarget();
        GetTarget Ma = new Entrepreneur();
        Ma.getTarget();
    }
}*/


