package poly;
public class Person{
    private String name;
    private int age;

    public void getTarget(){
        System.out.println("美好生活");
}
    public static void show_target() {
        System.out.print(" 目标 ");
    }
}
