package poly;
public class Teacher extends Person{
    @Override
    public void getTarget(){
        System.out.println("传道授业解惑");
    }
}
