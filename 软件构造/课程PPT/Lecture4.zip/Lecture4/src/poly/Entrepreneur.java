package poly;
public class Entrepreneur implements GetTarget{
    @Override
    public void getTarget(){
        System.out.println("促进共同富裕");
    }
}
