package DIP;

public class Book {
    public String getContent(){
        return "曾经有个大难不死的男孩……";
    }
}


/*public class Book implements IReader{
    public String getContent(){
        return "曾经有个大难不死的男孩…………";
    }
}*/
