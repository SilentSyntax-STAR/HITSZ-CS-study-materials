package DIP;

public interface IReader {
    public String getContent();
}
