package DIP;

public class Client {
    public static void main(String[] args){
        Mother mother = new Mother();
        Book book = new Book();
        mother.narrate(book);
    }
}

/*public class Client {
    public static void main(String[] args){
        Mother mother = new Mother();
        // 用继承与多态来减少具体产品类（Book,Newspaper）与客户端类(Mother)的耦合
        IReader book = new Book(); //父类的引用指向子类
        mother.narrate(book);
        IReader newspaper = new Newspaper();
        mother.narrate(newspaper);
    }
}*/
