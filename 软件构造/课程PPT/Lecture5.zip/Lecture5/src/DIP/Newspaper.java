package DIP;

public class Newspaper implements IReader {
    public String getContent(){
        return "在地底洞穴中住着一个霍比特人……";
    }
}
