package simplefactory;

public class PizzaStore {
    public static Pizza orderPizza(String type){
        Pizza pizza;

        pizza = SimplePizzaFactory.createPizza(type); //static方法

        pizza.prepare();
        pizza.bake();
        pizza.cut();
        pizza.box();

        return pizza;
    }

    public static void main(String[] args){
        PizzaStore.orderPizza("greek");
    }
}
