package simplefactory;

public class SimplePizzaFactory {
    public static Pizza createPizza(String type){ //声明为static方法
        Pizza pizza = null;

        if (type.equals("cheese"))
            pizza = new CheesePizza();
        if (type.equals("greek"))
            pizza = new GreekPizza();
        if (type.equals("pepperoni"))
            pizza = new PepperoniPizza();

        return pizza;
    }
}
