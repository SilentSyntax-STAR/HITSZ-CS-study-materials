package factory;

public class CheesePizza extends Pizza {
    @Override
    public void prepare(){
        System.out.println("准备CheesePizza");
    }
    public void bake(){
        System.out.println("烘烤CheesePizza");
    }
    public void cut(){
        System.out.println("切片CheesePizza");
    }
    public void box(){
        System.out.println("装盒CheesePizza");
    }
}

