package factory;

public class PepperoniPizza extends Pizza {
    @Override
    public void prepare(){
        System.out.println("准备PepperoniPizza");
    }
    public void bake(){
        System.out.println("烘烤PepperoniPizza");
    }
    public void cut(){
        System.out.println("切片PepperoniPizza");
    }
    public void box(){
        System.out.println("装盒PepperoniPizza");
    }
}
