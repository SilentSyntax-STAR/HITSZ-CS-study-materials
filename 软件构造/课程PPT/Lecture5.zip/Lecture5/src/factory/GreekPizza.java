package factory;


public class GreekPizza extends Pizza {
    @Override
    public void prepare(){
        System.out.println("准备GreekPizza");
    }
    public void bake(){
        System.out.println("烘烤GreekPizza");
    }
    public void cut(){
        System.out.println("切片GreekPizza");
    }
    public void box(){
        System.out.println("装盒GreekPizza");
    }
}
