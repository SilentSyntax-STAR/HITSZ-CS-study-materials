package factory;

public class Test {
    public static void main(String[] args){
        PizzaStore nyStore = new NYPizzaStore();
        PizzaStore chicagoStore = new ChicagoPizzaStore();

        Pizza pizza1 = nyStore.orderPizza("cheese");
        Pizza pizza2 = chicagoStore.orderPizza("veggie");
    }
}
