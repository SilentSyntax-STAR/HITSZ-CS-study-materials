package factory;

public class VeggiePizza extends Pizza {
    @Override
    public void prepare(){
        System.out.println("准备VeggiePizza");
    }
    public void bake(){
        System.out.println("烘烤VeggiePizza");
    }
    public void cut(){
        System.out.println("切片VeggiePizza");
    }
    public void box(){
        System.out.println("装盒VeggiePizza");
    }
}

