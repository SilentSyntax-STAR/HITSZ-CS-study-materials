package factory;

public class ChicagoPizzaStore extends PizzaStore{
    Pizza createPizza(String type){
        Pizza pizza = null;

        if (type.equals("cheese"))
            pizza = new CheesePizza();
        if (type.equals("greek"))
            pizza = new GreekPizza();
        if (type.equals("veggie"))
            pizza = new VeggiePizza();

        return pizza;
    }
}


