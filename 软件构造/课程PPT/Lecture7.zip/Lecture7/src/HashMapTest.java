import java.util.*;
import java.util.Map.Entry;
public class HashMapTest {
    public static void main(String[] args) {
        HashMap<Integer, String> sites = new HashMap();
        //增加元素
        // 添加键值对
        sites.put(1, "Google");
        sites.put(2, "Amazon");
        sites.put(300, "Taobao");
        sites.put(45, "Zhihu");
        sites.put(5, "Zhihu"); //键不可重复，值可重复
        System.out.println(sites);

        //删除元素
        sites.remove(300);//通过删除键来删除对应的键值对
        sites.remove(1,"Google");//直接删除键值对
        System.out.println("After removal," + sites);

        //修改元素
        sites.put(1,"Jingdong");//跟添加方式一样
        System.out.println("After modification," + sites);

        //查询元素
        System.out.println(sites.get(2)); //通过键来获取对应的值

        //集合大小
        System.out.println(sites.size());


        //for each 循环遍历
        System.out.println("--------2.for each 循环遍历-------");
        // 输出 key（如果你只想获取 key，可以使用 keySet() 方法）
        for (Integer i : sites.keySet()) {
            System.out.println("key:" + i );
            //如果还想获取对应的value，可用get，通过键值来获取value
            System.out.println("key:" + i + "value:" + sites.get(i));
        }
        // 输出 value 值（如果你只想获取 value，可以使用 values() 方法）
        for(String value: sites.values()) {
            System.out.print(value + ",");
        }

        /*//迭代器遍历
        System.out.println("--------3.迭代器遍历-------");
        //遍历key
        Iterator itk = sites.keySet().iterator();
        while(itk.hasNext()){
            System.out.println(itk.next());
        }
        //遍历value
        Iterator itv = sites.values().iterator();
        while(itv.hasNext()){
            System.out.println(itv.next());
        }
        //遍历key和value
        Iterator < Entry <Integer,String>> itkv = sites.entrySet().iterator();
        while(itkv.hasNext()){
            Entry <Integer,String> entry = itkv.next();
            System.out.println("key:" +entry.getKey() + "value:" + entry.getValue());
        } */

    }
}



