package IteratorPattern;

public interface Iterator {
    /**
     * 删除对象
     * @return 对象
     */
    Object remove();

    /**
     * 调用下一个对象
     * @return 对象
     */
    Object next();

    /**
     * 迭代器中是否还有下一个对象
     * @return
     */
    boolean hasNext();


}
