package IteratorPattern;

public class Client {

    public static void main(String[] args) {
        ConcreteContainer concreteAggregate=new ConcreteContainer();
        concreteAggregate.add("Harry");
        concreteAggregate.add("Ron");
        concreteAggregate.add("Luna");

        System.out.println("聚合对象有：");

        Iterator iterator=concreteAggregate.getIterator();

        while (iterator.hasNext()){
            Object next = iterator.next();
            System.out.println(next.toString());
        }

    }

}
