import java.util.*;
public class HashSetTest {
    public static void main(String[] args) {
        HashSet<String> sites = new HashSet();
        //增加元素
        sites.add("Google");
        sites.add("Amazon");
        sites.add("Taobao");
        sites.add("Weibo");
        sites.add("Weibo"); // 重复的元素不会被添加
        System.out.println(sites); //结果无序
        // 再跑一遍是不是还是这个顺序？

        //不能通过下标删除元素
        sites.remove("Google");//直接删除
        System.out.println("After removal," + sites);

        //不能通过下标查询元素

        //不能通过下标修改元素

        //判断元素是否存在
        System.out.println(sites.contains("Taobao"));
        System.out.println(sites.contains("Google"));

        //集合大小
        System.out.println(sites.size());

        //遍历元素
        //无for 循环遍历

        //for each 循环遍历
        System.out.println("--------2.for each 循环遍历-------");
        for (String i : sites) {
            System.out.println(i);
        }

        //迭代器遍历
        System.out.println("--------3.迭代器遍历-------");
        Iterator it = sites.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }

        //无列表迭代器遍历，因为不是List

    }

    }