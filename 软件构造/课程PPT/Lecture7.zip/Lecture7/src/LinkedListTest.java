import java.util.*;
public class LinkedListTest {
    public static void main(String[] args) {
        LinkedList a = new LinkedList();
        a.add("Google");
        a.add(123);
        a.add(true);
        System.out.println(a);

        LinkedList<String> sites = new LinkedList();
        //增加元素
        sites.add("Google");
        sites.add("Amazon");
        sites.add("Taobao");
        sites.add("Weibo");
        sites.add(1,"Baidu");
        System.out.println("After addition," + sites);

        //删除元素
        sites.remove(3);
        sites.remove("Google");
        System.out.println("After removal," + sites);

        //查询元素
        System.out.println(sites.get(1));

        //修改元素
        sites.set(1,"Jingdong");
        System.out.println("After modification," + sites);

        //集合大小
        System.out.println(sites.size());

        //*******特有功能*******
        System.out.println("*******LinkedList特有功能*******");
        sites.addFirst("Wiki");
        sites.addLast("Wiki");
        sites.removeFirst();
        sites.removeLast();
        sites.getFirst();
        sites.getLast();
        System.out.println(sites);


        //遍历元素
        //for 循环遍历
        System.out.println("--------1.for 循环遍历-------");
        for (int i = 0; i < sites.size(); i++) {
            System.out.println(sites.get(i));
        }

        //for each 循环遍历
        System.out.println("--------2.for each 循环遍历-------");
        for (String i : sites) {
            System.out.println(i);
        }


        /*
        //迭代器遍历
        System.out.println("--------3.迭代器遍历-------");
        Iterator it = sites.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }

        //列表迭代器遍历
        System.out.println("--------4.列表迭代器遍历-------");
        ListIterator lit = sites.listIterator();
        while(lit.hasNext()){
            System.out.println(lit.next());
        }

         */
    }
}


