import java.util.*;
public class ArrayListTest {
    public static void main(String[] args){

        //数组存放不同数据类型，需声明
        Object[] b = {1,true,"google"};
        for (Object i : b) {
            System.out.println(i);
        }

        //集合存放不同数据类型，无需声明
        ArrayList a = new ArrayList();
        a.add("Google");
        a.add(123);
        a.add(true);
        System.out.println(a);


        ArrayList<String> sites = new ArrayList();
        //增加元素
        sites.add("Google");
        sites.add("Amazon");
        sites.add("Taobao");
        sites.add("Weibo");
        sites.add("Weibo"); // 重复的元素可以被添加
        sites.add(1,"Baidu");//根据下标插入，后面后移
        System.out.println("After addition," + sites);

        //删除元素
        sites.remove(3); // 通过下标删除
        sites.remove("Google"); // 直接删除
        System.out.println("After removal," + sites);

        //查询元素
        System.out.println(sites.get(1));

        //修改元素
        sites.set(1,"Jingdong"); // 通过下标修改
        System.out.println("After modification," + sites);

        //集合大小
        System.out.println(sites.size());


        //遍历元素
        //for 循环遍历
        System.out.println("--------1.for 循环遍历-------");
        for (int i = 0; i < sites.size(); i++) {
            System.out.println(sites.get(i));
        }

        //for each 循环遍历
        System.out.println("--------2.for each 循环遍历-------");
        for (String i : sites) {
            System.out.println(i);
        }

        /*
        //迭代器遍历
        System.out.println("--------3.迭代器遍历-------");
        Iterator it = sites.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }

        //列表迭代器遍历
        System.out.println("--------4.列表迭代器遍历-------");
        ListIterator lit = sites.listIterator();
        while(lit.hasNext()){
            System.out.println(lit.next());
        }


         */

    }
}
