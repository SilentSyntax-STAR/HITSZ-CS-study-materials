package StrategyPattern;
import java.util.Scanner;

public class Network {

    //持有一个具体的策略对象
    private MemberStrategy strategy;

    /**
     * 构造函数，传入一个具体的策略对象
     *
     * @param strategy 具体的策略对象
     */
    public Network(MemberStrategy strategy) {
        this.strategy = strategy;
    }

    /**
     * 计算图书的价格
     *
     * @param booksPrice 图书的原价
     * @return 计算出打折后的价格
     */
    public double quote(double booksPrice) {
        System.out.println("好好学习，天天向上");//办理会员都要鼓励
        return this.strategy.calcPrice(booksPrice);

        //执行条件


/*        int answer;
        Scanner input = new Scanner(System.in);
        System.out.println("请回答你是否有学生证，没有请返回1,有请返回0");
        answer = input.nextInt();
        if (answer == 1) {
            System.out.println("有学生证才能打折");
        } else if (answer == 0) {
            // 每个策略类都需要执行的代码
            System.out.println("好好学习，天天向上");//办理会员都要鼓励
            return this.strategy.calcPrice(booksPrice);
        }
        return booksPrice; //返回原价*/









    }
}

