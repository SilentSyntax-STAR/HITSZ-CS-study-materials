package StrategyPattern;

public class Client {
    public static void main(String[] args) {
//选择并创建需要使用的策略对象
      MemberStrategy strategy = new AdvancedMemberStrategy();
//创建环境
      Network network = new Network(strategy);
//计算价格
    double quote = network.quote(300);

  //  double quote = strategy.calcPrice(300);

    System.out.println("图书的最终价格为：" + quote); }
}

