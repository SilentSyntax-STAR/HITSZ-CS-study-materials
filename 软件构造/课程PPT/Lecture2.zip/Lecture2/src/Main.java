

/*public class Main {
    public static void main(String[] args) {
        char c1='a';
        char c2='b';
        char c3='\n';
        System.out.println(c1+c2);
        System.out.println(\u000a); // \n换行
        System.out.println(c1+c3);
    }
}*/




/*public class Main {
    public static void main(String[] args) {
        int a=123456789;
        float f=a;
        System.out.println(f);

    }
}*/


/*import java.io.*;
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader stdin =new BufferedReader(new InputStreamReader(System.in));
        System.out.println("What is your name?");
        System.out.println(stdin.readLine());
    }
}*/

/*
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in);
        System.out.println("What is your name?");
        System.out.println(stdin.nextLine());
    }
}*/



public class Main {
    public static void main(String[] args) {
        try {
            int i = 1 / 0;//发生异常立即跳往catch语句中执行，不执行异常代码下面的代码
            System.out.println("输出结果为：" + i);
        } catch (ArithmeticException e) { //算数异常
            e.printStackTrace(); //在命令行打印异常信息在程序中出错的位置及原因
            System.out.println("编译报错，除数不能为0");
          return;
        }
        finally{
            System.out.println("finally");
        }
        System.out.println("aaaa");
    }
}



/*
public class Main {
    public static void main(String[] args) {
        int[] a = new int[]{1,2,3,4,5};
        try {
            int b = a[5];//发生异常立即跳往catch语句中执行，不执行异常代码下面的代码
            System.out.println("输出结果为：" + b);
        } catch (IndexOutOfBoundsException e) { //算数异常
            e.printStackTrace();
            System.out.println("编译报错，数组越界");
        }
        finally{
            System.out.println("finally");
        }
    }
}
*/


