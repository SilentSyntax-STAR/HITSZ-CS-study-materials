public class DaemonTest {
    public static void main(String[] args){
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                int sum = 0;
                for (int i = 1; i  <= 100; i++) {
                    sum = sum + i;
                }
                System.out.println("守护线程，最终求和的值为： " + sum);
            }
        });
        thread.setDaemon(true); //设置thread为守护线程
        thread. start();

        //但是实际的开发过程中，这样的操作是不允许的，因为守护线程，
        //默认就是不需要被用户线程等待的，是服务于用户线程的。
/*
        try {
            thread.join(); // 加入join 方法
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/


        System.out.println("main 函数线程执行完毕， JVM 退出。");
    }
}
