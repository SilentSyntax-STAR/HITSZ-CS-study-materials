public class TicketDemo2 {
    public static void main(String[] args)
    {
		Ticket t = new Ticket();//将卖票这一行为封装成对象

        //多线程共享一个对象（t），
		Thread j1 = new Thread(t);
		Thread j2 = new Thread(t);

		j1.start(); j2.start();
    }
}

class Ticket implements Runnable
{
    private int num = 10;
    public void run()
    {
        while(true)
        {
            if(num>0)
            {
                System.out.println(Thread.currentThread().getName()+"..sale.."+num--);
            }
        }
    }
}