public class AddDec {
    public static void main(String[] args) throws Exception {
        AddThread add = new AddThread();
        DecThread dec = new DecThread();
        add.start();
        dec.start();
        add.join();
        dec.join();
        System.out.println(Counter.count);
    }
}

class Counter {

    public static final Object lock = new Object(); //创建一个共享的锁对象，static 使得 lock 属于类级别，而不是实例级别
  //   public static final Object lock2 = new Object();
    public static int count = 0;
}

class AddThread extends Thread {
    public void run() {
   //     synchronized(Counter.lock) { //线程一拿到锁
            for (int i = 0; i < 10000000; i++) {
                Counter.count += 1;
            }
   //     }
    }
}

class DecThread extends Thread {
    public void run() {
    //      synchronized(Counter.lock) { //线程一释放后，线程二拿到锁
        for (int i=0; i<10000000; i++) {
            Counter.count -= 1;}
    }
  //   }
}

