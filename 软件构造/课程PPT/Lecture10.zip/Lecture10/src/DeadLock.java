public class DeadLock {
    public static String Money = "钱";
    public static String Food = "饭";
    public static void main(String[] args) {
        PerA la = new PerA();
        new Thread(la).start();
        PerB lb = new PerB();
        new Thread(lb).start();
    }
}
class PerA implements Runnable{
    public void run() {
        try {
            System.out.println( " PerA: 我有钱请给我饭");
            while(true){
                synchronized (DeadLock.Money) {
                    System.out.println(" PerA 锁住钱");
                    Thread.sleep(3000); // 此处等待是给B机会
                    synchronized (DeadLock.Food) {
                        System.out.println(" PerA 吃到饭");
                        Thread.sleep(60 * 1000); // 为测试，占用了就不放
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
class PerB implements Runnable{
    public void run() {
        try {
            System.out.println(" PerB： 我有饭请给我钱");
            while(true){
                synchronized (DeadLock.Food) {
                    System.out.println(" PerB锁住饭");
                    Thread.sleep(3000); // 此处等待是给A机会
                    synchronized (DeadLock.Money) {
                        System.out.println(" PerB拿到钱");
                        Thread.sleep(60 * 1000); // 为测试，占用了就不放
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}