public class InterruptTest {
    public static void main(String[] args) {
        System.out.println("interrupt()并不是中断线程，而是将线程中断标志为设置为true");
        new Thread(
                ()->
                {
                    Thread thread = Thread.currentThread();
                    for (int i=0;i<5;i++) {
                   // for (int i=0;i<5&&!thread.isInterrupted();i++) {
                        System.out.println("线程" + thread.getName() + "i=" + i + "isInterrupted=" + thread.isInterrupted());
                        if (i == 2) {
                            thread.interrupt();
                        }
                    }
                    System.out.println("线程" + thread.getName() + "停止运行" + "isInterrupted=" + thread.isInterrupted());
                }).start();
                }
    }


