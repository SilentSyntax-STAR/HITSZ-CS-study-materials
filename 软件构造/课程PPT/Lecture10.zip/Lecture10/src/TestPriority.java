public class TestPriority {
    public static void main(String[] args) {
        //打印主线程的优先级
        System.out.println(Thread.currentThread().getName() + "->" + Thread.currentThread().getPriority());
        //创建一个线程任务
        MyPriority myPriority = new MyPriority();
        //创建线程代理对象
        Thread thread1 = new Thread(myPriority);
        Thread thread2 = new Thread(myPriority);
        Thread thread3 = new Thread(myPriority);
        Thread thread4 = new Thread(myPriority);
        Thread thread5 = new Thread(myPriority);
        //设置线程优先级并执行
        thread1.setPriority(1);
        thread1.start();

        thread2.setPriority(3);
        thread2.start();

        thread3.setPriority(5);
        thread3.start();

        thread4.setPriority(8);
        thread4.start();

        thread5.setPriority(10);
        thread5.start();

    }

}

class MyPriority implements Runnable {
    @Override
    public void run() {
        //获取并打印线程的优先级
        System.out.println(Thread.currentThread().getName() + "->" + Thread.currentThread().getPriority());
    }
}
