public class PolyjuicePotion {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("建立Thread类的子类来实现");
        long startTime = System.currentTimeMillis();
        // 第一步 网购坩埚
        OnlineShopping thread = new OnlineShopping();
        thread.start();
        thread.join();  // 保证坩埚送到（就是调用join方法阻塞主线程）
        // 如果要保存run里面的计算结果，必须等待run方法运算完,ganguo才会被赋值
        // 第二步 去魔法超市买材料（头发）
        Thread.sleep(2000);  // 模拟购买材料时间
        Cailiao cailiao = new Cailiao();
        System.out.println("第二步：材料到位");
        // 第三步 用坩埚熬制复方汤剂
        System.out.println("第三步：开始表演");
        brew(thread.ganguo, cailiao);

        System.out.println("总共用时" + (System.currentTimeMillis() - startTime) + "ms");
    }

    // 网购坩埚线程
    static class OnlineShopping extends Thread {

        private Ganguo ganguo;

        @Override
        public void run() {
            System.out.println("第一步：下单");
            System.out.println("第一步：等待送货");
            try {
                Thread.sleep(5000);  // 模拟送货时间
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("第一步：快递送到");
            ganguo = new Ganguo();
        }

    }

    //  用坩埚熬制材料
    static void brew(Ganguo ganguo, Cailiao cailiao) {}

    // 坩埚类
    static class Ganguo {}

    // 材料类
    static class Cailiao {}
}
