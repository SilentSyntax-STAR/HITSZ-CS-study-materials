import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

public class PolyjuicePotionFuture {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        System.out.println("用FutureTask来实现");
        long startTime = System.currentTimeMillis();
        // 第一步 网购坩埚
        //把耗时的网购坩埚逻辑，封装到了一个callable的call方法里面
        Callable<Ganguo> onlineShopping = new Callable<Ganguo>() {

            @Override
            public Ganguo call() throws Exception {
                System.out.println("第一步：下单");
                System.out.println("第一步：等待送货");
                Thread.sleep(5000);  // 模拟送货时间
                System.out.println("第一步：快递送到");
                return new Ganguo();
            }

        };
        //异步执行：把callable实例当作参数生成一个FutureTask的对象，作为参数另起线程
        FutureTask<Ganguo> task = new FutureTask<Ganguo>(onlineShopping);
        new Thread(task).start();
        // 第二步 去魔法超市购买材料
        Thread.sleep(2000);  // 模拟购买材料时间
        Cailiao cailiao = new Cailiao();
        System.out.println("第二步：材料到位");
        // 第三步 用坩埚熬制复方汤剂
        if (!task.isDone()) {  // 联系快递员，询问是否到货
            System.out.println("第三步：坩埚还没到，心情好就等着（心情不好还可以调用cancel方法取消订单）");
        }
        Ganguo ganguo = task.get();
        System.out.println("第三步：坩埚到位，开始表演");
        brew(ganguo, cailiao);

        System.out.println("总共用时" + (System.currentTimeMillis() - startTime) + "ms");
    }

    //  用坩埚熬制材料
    static void brew(Ganguo ganguo, Cailiao cailiao) {}

    // 坩埚类
    static class Ganguo {}

    // 材料类
    static class Cailiao {}

}
