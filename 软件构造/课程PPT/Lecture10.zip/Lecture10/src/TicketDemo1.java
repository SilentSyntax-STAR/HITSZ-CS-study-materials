public class TicketDemo1 {
    public static void main(String[] args)
    {
        //每个线程创建一个实例对象，互不影响
        QuidditchTicket j1 = new QuidditchTicket();
        QuidditchTicket j2 = new QuidditchTicket();

        j1.start(); j2.start();
    }
}

class QuidditchTicket extends Thread
{
    private int num = 10;
    public void run()
    {
        while(true)
        {
            if(num>0)
            {
                System.out.println(Thread.currentThread().getName()+"..sale.."+num--);
            }
        }
    }
}
