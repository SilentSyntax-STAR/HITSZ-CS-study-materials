#include "Action.h"
#ifdef __cplusplus
extern "C" {
#endif
void ForwardAction(Pose *pose)
{
 if (pose->heading == EAST) {
 pose->pos.x += 1;} 
 else if (pose->heading == WEST) {
 pose->pos.x -= 1;
 } else if (pose->heading == NORTH) {
 pose->pos.y += 1;
 } else if (pose->heading == SOUTH) {
 pose->pos.y -= 1;
 }
}

void TurnRightAction(Pose *pose) {
    if (pose->heading == NORTH) {
        pose->heading = EAST;
    } else if (pose->heading == EAST) {
        pose->heading = SOUTH;
    } else if (pose->heading == SOUTH) {
        pose->heading = WEST;
    } else if (pose->heading == WEST) {
        pose->heading = NORTH;
    }
}

void TurnLeftAction(Pose *pose) {
    if (pose->heading == NORTH) {
        pose->heading = WEST;
    } else if (pose->heading == WEST) {
        pose->heading = SOUTH;
    } else if (pose->heading == SOUTH) {
        pose->heading = EAST;
    } else if (pose->heading == EAST) {
        pose->heading = NORTH;
    }
}

void BackwardAction(Pose *pose)
{
    if (pose->heading == NORTH) {
        pose->pos.y -= 1; // 向北的反方向是向南，所以y坐标减1
    } else if (pose->heading == EAST) {
        pose->pos.x -= 1; // 向东的反方向是向西，所以x坐标减1
    } else if (pose->heading == SOUTH) {
        pose->pos.y += 1; // 向南的反方向是向北，所以y坐标加1
    } else if (pose->heading == WEST) {
        pose->pos.x += 1; // 向西的反方向是向东，所以x坐标加1
    }
}

void ReverseTurnLeftAction(Pose *pose)
{
    if (pose->heading == NORTH) {
        pose->heading = EAST;
    } else if (pose->heading == EAST) {
        pose->heading = SOUTH;
    } else if (pose->heading == SOUTH) {
        pose->heading = WEST;
    } else if (pose->heading == WEST) {
        pose->heading = NORTH;
    }
}

void ReverseTurnRightAction(Pose *pose) {
    if (pose->heading == NORTH) {
        pose->heading = WEST;
    } else if (pose->heading == WEST) {
        pose->heading = SOUTH;
    } else if (pose->heading == SOUTH) {
        pose->heading = EAST;
    } else if (pose->heading == EAST) {
        pose->heading = NORTH;
    }
}
#ifdef __cplusplus
}
#endif