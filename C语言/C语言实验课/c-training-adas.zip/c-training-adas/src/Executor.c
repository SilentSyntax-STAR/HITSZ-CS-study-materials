#include "Executor.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "Action.h"
#include "State.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct {
Pose pose;
bool isFast;
int32_t x;
int32_t y;
char heading;// 是否加速
} Executor;

static Executor sys = {.pose = {.pos = {.x = 0, .y = 0}, .heading = NORTH}};

void ExecutorInitialize(const Pose pose)
{
sys.pose = pose;
sys.isFast = false;
}

void MoveCommand()
{
if (sys.isFast) {
ForwardAction(&sys.pose);
ForwardAction(&sys.pose);
} else {
    ForwardAction(&sys.pose);
}
}
void TurnLeftCommand()
{
if (sys.isFast) { // 加速状态下转向前需要移动一格
ForwardAction(&sys.pose);
}
TurnLeftAction(&sys.pose);
}

void TurnRightCommand()
{
if (sys.isFast) { // 加速状态下转向前需要移动一格
ForwardAction(&sys.pose);
}
TurnRightAction(&sys.pose);
}

void FastCommand()
{
sys.isFast = !sys.isFast;
}

void BackwardCommand()
{
    BackwardAction(&sys.pose);
}

void ReverseTurnLeftCommand()
{
    ReverseTurnLeftAction(&sys.pose);
}

void ReverseTurnRightCommand()
{
    ReverseTurnRightAction(&sys.pose);
}

void ExecutorExecCommands(const char *cmds) {
    int i = 0;
    int len = strlen(cmds);
    while (i < len) {
        if (cmds[i] == 'M') {
            MoveCommand();
            i++;
        } else if (cmds[i] == 'L') {
            TurnLeftCommand();
            i++;
        } else if (cmds[i] == 'R') {
            TurnRightCommand();
            i++;
        } else if (i + 1 < len && cmds[i] == 'B' && cmds[i + 1] == 'M') {
            BackwardCommand();
            i += 2;
        } else if (i + 1 < len && cmds[i] == 'B' && cmds[i + 1] == 'L') {
            ReverseTurnLeftCommand();
            i += 2;
        } else if (i + 1 < len && cmds[i] == 'B' && cmds[i + 1] == 'R') {
            ReverseTurnRightCommand();
            i += 2;
        }else if(i + 1 < len && cmds[i] == 'F' && cmds[i + 1] == 'M'&& cmds[i + 2] == 'L'&& cmds[i + 3] == 'M'){
            MoveCommand();
            MoveCommand();
            MoveCommand();
            TurnLeftCommand();
            MoveCommand();
            MoveCommand();
            i+=4;
        }
}
}

//实现查询的接口
Pose ExecutorQuery()
{
return sys.pose;
}
#ifdef __cplusplus
}
#endif