#include "gtest/gtest.h"
#include "Executor.h"
#include "Pose.h"
#include "Direction.h"
#include <assert.h>

TEST(Executor, should_return_init_pose_when_without_command)//测试初始化
{
    // given
    //初始化接口
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = NORTH});
    // when   
    Pose pose = ExecutorQuery(); 
    // then
    ASSERT_EQ(pose.pos.x, 0);//比较x是不是0
    ASSERT_EQ(pose.pos.y, 0);//比较y是不是0
    ASSERT_EQ(pose.heading, NORTH);//比较heading是不是north
}
//往东前进一格
TEST(Executor,should_return_x_plus_1_given_command_is_M_and_facing_is_E)
{
    //given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = EAST});
    //when
    ExecutorExecCommands("M");
    //then
    Pose pose = ExecutorQuery();//查状态
    EXPECT_EQ(pose.pos.x, 1);
    EXPECT_EQ(pose.pos.y, 0);
    EXPECT_EQ(pose.heading, EAST);
    //如果以上条件都满足则代码成功
}
//往南前进一格
TEST(Executor, should_return_y_minus_1_given_command_is_M_and_facing_is_S)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = SOUTH});
    // when
    ExecutorExecCommands("M");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.pos.x, 0);
    EXPECT_EQ(pose.pos.y, -1);
    EXPECT_EQ(pose.heading, SOUTH);
}
//往北前进一格
TEST(Executor, should_return_y_plus_1_given_command_is_M_and_facing_is_N)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = NORTH});
    // when
    ExecutorExecCommands("M");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.pos.x, 0);
    EXPECT_EQ(pose.pos.y, 1);
    EXPECT_EQ(pose.heading, NORTH);
}
//往西前进一格
TEST(Executor, should_return_x_minus_1_given_command_is_M_and_facing_is_W)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = WEST});
    // when
    ExecutorExecCommands("M");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.pos.x, -1);
    EXPECT_EQ(pose.pos.y, 0);
    EXPECT_EQ(pose.heading, WEST);
}
//从东右转到南
TEST(Executor,should_return_facing_S_given_command_is_R_and_facing_is_E)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = EAST});
    // when
    ExecutorExecCommands("R");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, SOUTH);
}
//从南右转到西
TEST(Executor,should_return_facing_W_given_command_is_R_and_facing_is_S)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = SOUTH});
    // when
    ExecutorExecCommands("R");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, WEST);
}
//从西右转到北
TEST(Executor,should_return_facing_N_given_command_is_R_and_facing_is_W)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = WEST});
    // when
    ExecutorExecCommands("R");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, NORTH);
}
//从北右转到东
TEST(Executor,should_return_facing_E_given_command_is_R_and_facing_is_N)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = NORTH});
    // when
    ExecutorExecCommands("R");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, EAST);
}
//从北左转到西
TEST(Executor,should_return_facing_W_given_command_is_L_and_facing_is_N)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = NORTH});
    // when
    ExecutorExecCommands("L");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, WEST);
}
//从西左转到南
TEST(Executor,should_return_facing_S_given_command_is_L_and_facing_is_W)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = WEST});
    // when
    ExecutorExecCommands("L");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, SOUTH);
}
//从南左转到东
TEST(Executor,should_return_facing_E_given_command_is_L_and_facing_is_S)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = SOUTH});
    // when
    ExecutorExecCommands("L");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, EAST);
}
//从东左转到北
TEST(Executor,should_return_facing_N_given_command_is_L_and_facing_is_E)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = EAST});
    // when
    ExecutorExecCommands("L");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, NORTH);
}

TEST(Executor, should_return_y_minus_1_given_command_is_BM_and_facing_is_N)
{
    //given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = NORTH});
    //when
    ExecutorExecCommands("BM");
    //then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.pos.x, 0);  
    EXPECT_EQ(pose.pos.y, -1);
    EXPECT_EQ(pose.heading, NORTH); 
}

TEST(Executor, should_return_y_plus_1_given_command_is_BM_and_facing_is_S)
{
    //given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = SOUTH});
    //when
    ExecutorExecCommands("BM");
    //then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.pos.x, 0);  
    EXPECT_EQ(pose.pos.y, +1);
    EXPECT_EQ(pose.heading, SOUTH); 
}

TEST(Executor, should_return_x_minus_1_given_command_is_BM_and_facing_is_E)
{
    //given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = EAST});
    //when
    ExecutorExecCommands("BM");
    //then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.pos.x, -1);  
    EXPECT_EQ(pose.pos.y, 0);
    EXPECT_EQ(pose.heading, EAST); 
}

TEST(Executor, should_return_x_plus_1_given_command_is_BM_and_facing_is_W)
{
    //given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = WEST});
    //when
    ExecutorExecCommands("BM");
    //then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.pos.x, +1);  
    EXPECT_EQ(pose.pos.y, 0);
    EXPECT_EQ(pose.heading, WEST); 
}

//右后转（左转）
TEST(Executor,should_return_facing_N_given_command_is_BR_and_facing_is_E)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = EAST});
    // when
    ExecutorExecCommands("BR");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, NORTH);
}

TEST(Executor,should_return_facing_W_given_command_is_BR_and_facing_is_N)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = NORTH});
    // when
    ExecutorExecCommands("BR");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, WEST);
}

TEST(Executor,should_return_facing_S_given_command_is_BR_and_facing_is_W)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = WEST});
    // when
    ExecutorExecCommands("BR");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, SOUTH);
}

TEST(Executor,should_return_facing_E_given_command_is_BR_and_facing_is_S)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = SOUTH});
    // when
    ExecutorExecCommands("BR");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, EAST);
}

//左后转（右转）
TEST(Executor,should_return_facing_E_given_command_is_BL_and_facing_is_N)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = NORTH});
    // when
    ExecutorExecCommands("BL");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, EAST);
}

TEST(Executor,should_return_facing_N_given_command_is_BL_and_facing_is_W)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = WEST});
    // when
    ExecutorExecCommands("BL");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, NORTH);
}

TEST(Executor,should_return_facing_W_given_command_is_BL_and_facing_is_S)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = SOUTH});
    // when
    ExecutorExecCommands("BL");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, WEST);
}

TEST(Executor,should_return_facing_S_given_command_is_BL_and_facing_is_E)
{
    // given
    ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = EAST});
    // when
    ExecutorExecCommands("BL");
    // then
    Pose pose = ExecutorQuery();
    EXPECT_EQ(pose.heading, SOUTH);
}

TEST(Executor, should_return_x_minus2_y_3_given_command_is_FMLM_and_facing_is_N)
{
 // given
 ExecutorInitialize((Pose){.pos = {.x = 0, .y = 0}, .heading = NORTH});
 // when
 ExecutorExecCommands("FMLM");
 // then
 Pose pose = ExecutorQuery();
 ASSERT_EQ(pose.pos.x, -2);
 ASSERT_EQ(pose.pos.y, 3);
 ASSERT_EQ(pose.heading, WEST);
}
