#pragma once

// 定义结构体State，包含表示加速状态的变量isFast
typedef struct {
    bool isFast;
} State;