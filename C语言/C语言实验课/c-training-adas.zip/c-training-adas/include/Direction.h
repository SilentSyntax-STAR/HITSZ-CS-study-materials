#pragma once
#ifdef __cplusplus
extern "C" {
#endif
// 定义一个枚举类型表示车头方向
typedef enum {
EAST = 1,
SOUTH = 2,
WEST = 3,
NORTH = 0,
} Heading;
Heading TurnToLeft(Heading heading);
Heading TurnToRight(Heading heading);
#ifdef __cplusplus
}
#endif